package DBCreate;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BOWTableCreate {

	public BOWTableCreate() {
		Connection conn ;
		String url;
		
		PreparedStatement pstmt;
		url="jdbc:oracle:thin:@localhost:1521:zetta";
		try {
			conn =DriverManager.getConnection(url,"yong","2514");
			//1�� ���̺�
			System.out.println("ȸ�� ���̺� �����Ϸ�");
			String sql="create table BOW_USERINFO("+
					"u_id    varchar2(20) ,"+
					"u_pwd   varchar2(20) not null,"+
					"u_name  varchar2(20) not null,"+
					"u_birth varchar2(20) not null,"+
					"constraint user_PK_ID primary key(u_id))";
			pstmt=conn.prepareStatement(sql);
			pstmt.executeQuery();
			
			System.out.println("������ ���̺� �����Ϸ�.");
			String sql2="create table BOW_CODE(c_code  varchar2(2) ,c_state varchar2(10) not null , constraint CODE_PK_no primary key(c_code))";
			pstmt=conn.prepareStatement(sql2);
			pstmt.executeQuery();
			
			System.out.println("�ڵ��Է� �Ϸ�.");
			 
			String sql11="insert into BOW_CODE values('01','�⼮')";	
			pstmt=conn.prepareStatement(sql11);
			pstmt.executeQuery();
			String sql12="insert into BOW_CODE values('02','����')";	
			pstmt=conn.prepareStatement(sql12);
			pstmt.executeQuery();
			String sql13="insert into BOW_CODE values('11','���')";	
			pstmt=conn.prepareStatement(sql13);
			pstmt.executeQuery();
			String sql14="insert into BOW_CODE values('12','����')";	
			pstmt=conn.prepareStatement(sql14);
			pstmt.executeQuery();
			String sql15="insert into BOW_CODE values('21','����')";	
			pstmt=conn.prepareStatement(sql15);
			pstmt.executeQuery();
			String sql16="insert into BOW_CODE values('22','����')";	
			pstmt=conn.prepareStatement(sql16);
			pstmt.executeQuery();
			
			
			
			
			System.out.println("���� ���̺� �����Ϸ�");
			String sql4="create table BOW_STATE(s_no  number(7)  ,s_id  varchar2(20) ,s_day varchar2(20) not null,s_code varchar2(2) not null,"+
					"constraint STATE_PK_NO primary key (s_no),constraint STATE_FK_code FOREIGN KEY(s_code)REFERENCES BOW_CODE(c_code))";
			pstmt=conn.prepareStatement(sql4);
			pstmt.executeQuery();
			
			System.out.println("�޸� ���̺� �����Ϸ�.");
			String sql5="create table BOW_MEMO(m_no number(7),m_id varchar2(20) not null,m_day varchar2(20) not null,"+
						"m_text varchar2(2000) not null,m_isShow char(1) not null,constraint MEMO_PK_NO primary key(m_no),"+
						"constraint MEMO_FK_id FOREIGN KEY(m_id)REFERENCES BOW_USERINFO(u_id))";
			pstmt=conn.prepareStatement(sql5);
			pstmt.executeQuery();
			
		} catch (Exception e) {e.printStackTrace();}
	}

	public static void main(String[] args) {
		new BOWTableCreate();
	}

}
