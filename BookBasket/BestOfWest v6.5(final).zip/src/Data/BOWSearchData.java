package Data;

import java.io.Serializable;

public class BOWSearchData implements Serializable{
	public String s_name;
	public String s_startData;
	public String s_endData;
	public String s_code;
	
}
