package Data;

import java.io.Serializable;

public class BOWMemoData implements Serializable{
	//�޸� �ۼ��Ҷ� �ʿ��� �ʵ�
	public String memo_date;
	public String memo_text;
	public boolean memo_isSHow;
	public int x;
	public int y;
}
