package Manager;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import NETData.*;

//import de.javasoft.plaf.synthetica.*;

/*
 * 	�α��� ȭ���� ���� ��ȭ����
 * 	�α��� ����� ó���ϵ��� �Ѵ�.
 */
@SuppressWarnings("serial")
public class BMLoginDlg extends JFrame {

	BMMain main;
	JComboBox<String> cpbox;
	JTextField idF;
	JPasswordField pwF;
	JButton loginB;

	public BMLoginDlg() {

		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});

		setLayout(new BorderLayout());

		JLabel cpL = new JLabel("Company");
		JLabel idL = new JLabel("ID");
		JLabel pwL = new JLabel("Password");

		cpbox = new JComboBox<String>();
		cpbox.addItem("���α� 1ȣ��");
		cpbox.addItem("���α� 2ȣ��");
		cpbox.addItem("�������� 1ȣ��");

		idF = new JTextField();
		pwF = new JPasswordField();
		loginB = new JButton("LOGIN");

		main = new BMMain();

		loginB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				main.thisDisplay();
			}
		});

		JPanel p1 = new JPanel(new GridLayout(3, 1));
		p1.add(cpL);
		p1.add(idL);
		p1.add(pwL);

		JPanel p2 = new JPanel(new GridLayout(3, 1));
		p2.add(cpbox);
		p2.add(idF);
		p2.add(pwF);

		JPanel p3 = new JPanel(new BorderLayout());
		p3.add("West", p1);
		p3.add("Center", p2);
		p3.add("East", loginB);

		add("South", p3);

		setTitle("BeautyManager");
		setSize(400, 600);
		setVisible(true);

	}

	public static void main(String[] args) {

		try {
			// UIManager.setLookAndFeel("ch.randelshofer.quaqua.QuaquaLookAndFeel");
			// JFrame.setDefaultLookAndFeelDecorated(true);
			UIManager.setLookAndFeel("com.jtattoo.plaf.mcwin.McWinLookAndFeel");
			// UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
			// UIManager.setLookAndFeel("de.javasoft.plaf.synthetica.SyntheticaStandardLookAndFeel");
			// UIManager.setLookAndFeel("de.javasoft.plaf.synthetica.SyntheticaBlackStarLookAndFeel");
			// SyntheticaLookAndFeel.setFont("Dialog", 12);
		} catch (Exception e) {
			e.printStackTrace();
		}
		new BMLoginDlg();

	}

}
