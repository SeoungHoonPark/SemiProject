package Designer;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

import Calendar.*;

/*
 * 	�����̳� ���� ���� ȭ��
 */

@SuppressWarnings("serial")
public class BMDesignerAttend /* extends JPanel */ extends JPanel {

	JTable BMDAtable;
	DefaultTableModel BMDAmodel;
	JScrollPane BMDAsp;
	JComboBox<String> BMDAbox;
	JTextField BMDAField;
	JButton BMDAbtn;
	CalendarFrame calendar;

	public BMDesignerAttend() {

		// addWindowListener(new WindowAdapter() {
		// @Override
		// public void windowClosing(WindowEvent e) {
		// System.exit(0);
		// }
		// });

		// try {
		// UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		// } catch (Exception e) {
		// e.printStackTrace();
		// }

		calendar = new CalendarFrame();

		String[] title = { "������", "��ٽð�", "��ٽð�", "����", "����", "���", "����" };
		BMDAmodel = new DefaultTableModel(title, 0);
		BMDAtable = new JTable(BMDAmodel);
		BMDAsp = new JScrollPane(BMDAtable);

		BMDAbox = new JComboBox<String>();
		BMDAbox.addItem("�����̳ʸ�");

		BMDAField = new JTextField();

		BMDAbtn = new JButton("�˻�");

		JPanel p1 = new JPanel(new GridLayout(1, 3, 10, 10));
		p1.add(BMDAbox);
		p1.add(BMDAField);
		p1.add(BMDAbtn);

		TitledBorder Tborder = new TitledBorder("���� ����");

		JPanel p2 = new JPanel(new BorderLayout());
		p2.add("Center", BMDAsp);
		p2.add("South", p1);

		JPanel p3 = new JPanel(new BorderLayout());
		p3.add(p2);
		p3.setBorder(Tborder);

		setLayout(new BorderLayout());
		add("Center", calendar.contentPane);
		add("East", p3);

		// setTitle("BeautyManager");
		// setSize(1030, 550);
		// setVisible(true);

	}

	// public static void main(String[] args) {
	// new BMDesignerAttend();
	// }

}
