package Designer;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;

/*
 * 	�����̳� ���� ������ ���� ȭ�� ����
 * �����̸�, �޴��ȣ, �������, ����, �ּ�, �Ի���, �̸���, �޸�, ����
 */
@SuppressWarnings("serial")
public class BMDesignerInfo /* extends JPanel */ extends JPanel {
	JButton searchB, infoModifyB, deleteB, gOfficeB, lOfficeB;
	JTextField nameF, pAddrF, birthF, genderF, addrF, hireDateF, mailF, rankF, searchF;
	JTable table;
	JComboBox<String> Cbox;
	JLabel nameL, pAddrL, birthL, genderL, addrL, hireDateL, mailL, rankL;
	DefaultTableModel model;
	Image img = null;

	public BMDesignerInfo() {
		// this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// Toolkit kit = Toolkit.getDefaultToolkit();
		// img = kit.getImage("src/Customer/ple1.png");

		// try {
		// UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		// } catch (Exception e) {
		// e.printStackTrace();
		// }

		searchB = new JButton("�˻�");
		infoModifyB = new JButton("��������");
		deleteB = new JButton("����");
		gOfficeB = new JButton("���");
		lOfficeB = new JButton("���");

		nameL = new JLabel("�̸�");
		pAddrL = new JLabel("��ȭ��ȣ");
		birthL = new JLabel("�������");
		genderL = new JLabel("����");
		addrL = new JLabel("�ּ�");
		hireDateL = new JLabel("�Ի���");
		mailL = new JLabel("�̸���");
		rankL = new JLabel("����");

		nameF = new JTextField(10);
		pAddrF = new JTextField(10);
		birthF = new JTextField(10);
		genderF = new JTextField(10);
		addrF = new JTextField(10);
		hireDateF = new JTextField(10);
		mailF = new JTextField(10);
		rankF = new JTextField(10);
		searchF = new JTextField(10);

		String[] title = { "�̸�", "��ȭ��ȣ", "�������", "����", "�ּ�", "�Ի���", "�̸����ּ�", "����" };
		model = new DefaultTableModel(title, 0);
		table = new JTable(model);
		JScrollPane sp = new JScrollPane(table);

		String[] items = { "�̸�", "��ȭ��ȣ", "����" };
		Cbox = new JComboBox<String>(items);

		TitledBorder tborder = new TitledBorder("���� ����");
		TitledBorder cborder = new TitledBorder("���� ����");
		TitledBorder mborder = new TitledBorder("�˻� ���");

		JPanel p1 = new JPanel(new GridLayout(8, 1));
		p1.add(nameL);
		p1.add(pAddrL);
		p1.add(birthL);
		p1.add(genderL);
		p1.add(addrL);
		p1.add(mailL);
		p1.add(hireDateL);
		p1.add(rankL);

		JPanel p2 = new JPanel(new GridLayout(8, 1));
		p2.add(nameF);
		p2.add(pAddrF);
		p2.add(birthF);
		p2.add(genderF);
		p2.add(addrF);
		p2.add(mailF);
		p2.add(hireDateF);
		p2.add(rankF);
		
		JPanel p31 = new JPanel(new GridLayout(1,2));
		p31.add(infoModifyB);
		p31.add(deleteB);

		JPanel p3 = new JPanel(new BorderLayout());
		p3.add("West", p1);
		p3.add("East", p2);
		p3.add("South", p31);
		p3.setBorder(cborder);

		JPanel p4 = new JPanel(new GridLayout(1, 2));
		p4.add(Cbox);
		p4.add(searchF);

		JPanel p5 = new JPanel(new BorderLayout());
		p5.add("North", p4);
		p5.add("South", searchB);

		JPanel p6 = new JPanel(new GridLayout(1, 2));
		p6.add(gOfficeB);
		p6.add(lOfficeB);

		JPanel p7 = new JPanel(new BorderLayout());
		p7.add("North", p5);
		p7.add("South", p6);
		p7.setBorder(mborder);

		JPanel p8 = new JPanel(new BorderLayout());
		p8.add("North", p3);
		p8.add("South", p7);

		JPanel p9 = new JPanel(new BorderLayout());
		p9.add(sp);
		p9.setBorder(tborder);

		setLayout(new BorderLayout());
		add("East", p8);
		add("Center", p9);

		// this.setSize(700, 500);
		// this.setVisible(true);
	}

	// public static void main(String[] args) {
	// new BMDesignerInfo();
	// }

	// public void paint(Graphics g){
	// g.drawImage(img, x, y, observer)
	// }
}
