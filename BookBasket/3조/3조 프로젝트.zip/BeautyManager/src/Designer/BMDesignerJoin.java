package Designer;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

/*
 * 	�����̳� ���� ��� ��ȭ����
 */
@SuppressWarnings("serial")
public class BMDesignerJoin /* extends JDialog */ extends JDialog {
	JTextField nameF, aNameF, hireDateF, pAddrF1, pAddrF2, addrF, mailF, birthF;
	JLabel nameL, aNameL, genderL, birthL, rankL, hireDateL, emailL, pAddrL, addrL, ehireDateL, epAddrL, label1,
			binlabel1, binlabel2;
	JTextArea area;
	JComboBox<String> rankC, mailC, phoneC;
	JRadioButton male, female;
	TitledBorder infoBorder, bBorder;
	JScrollPane sp;
	JButton transB, cancelB;

	public BMDesignerJoin() {

		infoBorder = new TitledBorder("�⺻����");
		bBorder = new TitledBorder("���");

		// ��
		nameL = new JLabel("�����̸�");
		aNameL = new JLabel("�����̳ʸ�");
		genderL = new JLabel("����");
		rankL = new JLabel("��å");
		hireDateL = new JLabel("�Ի���");
		pAddrL = new JLabel("�޴���");
		addrL = new JLabel("�ּ�");
		ehireDateL = new JLabel("ex)20170213");
		epAddrL = new JLabel("*�ʼ��Է�*");
		epAddrL.setForeground(Color.red);
		emailL = new JLabel("�̸���");
		birthL = new JLabel("�������");
		label1 = new JLabel("@");
		binlabel1 = new JLabel();
		binlabel2 = new JLabel();

		// �ؽ�Ʈ�ʵ�
		nameF = new JTextField(10);
		aNameF = new JTextField(10);
		hireDateF = new JTextField(10);
		pAddrF1 = new JTextField(4);
		pAddrF2 = new JTextField(4);
		addrF = new JTextField(47);
		mailF = new JTextField(10);
		birthF = new JTextField(10);

		// �޺��ڽ�
		String phone[] = { "010", "011", "070" };
		String level[] = { "����", "�ο���", "����", "�Ŵ���", "�����̳�", "����" };
		String items[] = { "naver.com", "nate.com", "daum.net", "gmail.com" };
		phoneC = new JComboBox<String>(phone);
		mailC = new JComboBox<String>(items);
		rankC = new JComboBox<String>(level);
		rankC.setPreferredSize(new Dimension(96, 30));

		// ���
		area = new JTextArea();
		sp = new JScrollPane(area);

		// ������ư
		ButtonGroup bg = new ButtonGroup();
		male = new JRadioButton("�� ��");
		female = new JRadioButton("�� ��");
		bg.add(male);
		bg.add(female);

		// ��ư
		transB = new JButton("�� ��");
		cancelB = new JButton("�� ��");

		// ���ʶ� ����
		JPanel p1 = new JPanel(new GridLayout(5, 1, 2, 2));
		p1.add(nameL);
		p1.add(genderL);
		p1.add(birthL);
		p1.add(hireDateL);
		p1.add(pAddrL);

		// �����ʵ� ����
		JPanel p21 = new JPanel(new GridLayout(1, 3, 2, 2));
		p21.add(phoneC);
		p21.add(pAddrF1);
		p21.add(pAddrF2);
		
		JPanel p22 = new JPanel(new GridLayout(1, 2, 2, 2));
		p22.add(male);
		p22.add(female);
		
		JPanel p2 = new JPanel(new GridLayout(5, 1, 2, 2));
		p2.add(nameF);
		p2.add(p22);
		p2.add(birthF);
		p2.add(hireDateF);
		p2.add(p21);
		p2.setPreferredSize(new Dimension(180, 150));

		// �����ʶ� ����
		JPanel p3 = new JPanel(new GridLayout(5, 1, 2, 2));
		p3.add(aNameL);
		p3.add(rankL);
		p3.add(emailL);
		p3.add(ehireDateL);
		p3.add(epAddrL);

		// ���Ϲ���
		JPanel p31 = new JPanel(new BorderLayout());
		p31.add("Center", mailF);
		p31.add("East", label1);

		// �������ʵ� ����
		JPanel p41 = new JPanel(new GridLayout(1, 2, 2, 2));
		p41.add(p31);
		p41.add(mailC);
		JPanel p4 = new JPanel(new GridLayout(5, 1, 2, 2));
		p4.add(aNameF);
		p4.add(rankC);
		p4.add(p41);
		p4.add(binlabel1);
		p4.add(binlabel2);
		p4.setPreferredSize(new Dimension(180, 150));

		// ���� ����
		// JPanel p5 = new JPanel(new GridLayout(1, 2, 10, 10));
		JPanel p5 = new JPanel(new BorderLayout());
		p5.add("West", p1);
		p5.add("East", p2);
		// p5.add(p1);
		// p5.add(p2);

		// ������ ����
		// JPanel p6 = new JPanel(new GridLayout(1, 2, 10, 10));
		JPanel p6 = new JPanel(new BorderLayout());
		p6.add("West", p3);
		p6.add("East", p4);
		// p6.add(p3);
		// p6.add(p4);

		// �⺻���� ����
		JPanel p7 = new JPanel(new GridLayout(1, 2, 25, 0));
		// JPanel p7 = new JPanel(new BorderLayout());
		// p7.add("West", p5);
		// p7.add("East", p6);
		p7.add(p5);
		p7.add(p6);

		// �ּ�
		JPanel p8 = new JPanel(new BorderLayout());
		p8.add("West", addrL);
		p8.add("East", addrF);

		// ���, �����ҹ�ư ����
		JPanel p91 = new JPanel();
		p91.add(transB);
		p91.add(cancelB);
		JPanel p9 = new JPanel(new BorderLayout());
		p9.add("Center", sp);
		p9.add("South", p91);
		p9.setBorder(bBorder);

		// �⺻����, �ּ� ����
		JPanel p10 = new JPanel(new BorderLayout());
		p10.add("Center", p7);
		p10.add("South", p8);
		p10.setBorder(infoBorder);

		setLayout(new BorderLayout());
		// this.add("West", p3);
		// this.add("East", p4);
		this.add("North", p10);
		this.add("Center", p9);
		setTitle("Beauty Manager �����̳� ���");
		setSize(667, 400);
		setResizable(false);
		setVisible(true);

		// JPanel p1 = new JPanel(new BorderLayout(10, 10));
		// p1.add("West", nameL);
		// p1.add("East", nameF);
		//
		// // �����̳ʸ�
		// JPanel p2 = new JPanel(new BorderLayout());
		// p2.add("West", aNameL);
		// p2.add("East", aNameF);
		//
		// // ��å
		// JPanel p3 = new JPanel(new BorderLayout());
		// p3.add("West", rankL);
		// p3.add("East", rankC);
		//
		// // ����
		// JPanel p4 = new JPanel(new BorderLayout());
		// p4.add("West", male);
		// p4.add("East", female);
		// JPanel p5 = new JPanel(new BorderLayout());
		// p5.add("West", genderL);
		// p5.add("East", p4);
		//
		// // �Ի���
		// JPanel p6 = new JPanel(new BorderLayout());
		// p6.add("West", hireDateL);
		// p6.add("East", hireDateF);
		//
		// // ���Ϲ���
		// JPanel p71 = new JPanel(new BorderLayout());
		// p71.add(mailF, "Center");
		// p71.add(label1, "East");
		// JPanel p7 = new JPanel(new GridLayout(1, 3));
		// p7.add(emailL);
		// p7.add(p71);
		// p7.add(mailC);
		//
		// // �޴���
		// // JPanel p10 = new JPanel(new BorderLayout());
		// // p10.add("West", phoneC);
		// // p10.add("East", pAddrF1);
		// // JPanel p11 = new JPanel(new BorderLayout());
		// // p11.add("West", p10);
		// // p11.add("East", pAddrF2);
		// JPanel p11 = new JPanel(new GridLayout(1, 3, 10, 0));
		// p11.add(phoneC);
		// p11.add(pAddrF1);
		// p11.add(pAddrF2);
		//
		// JPanel p12 = new JPanel(new BorderLayout(50, 0));
		// p12.add("West", pAddrL);
		// p12.add("Center", p11);
		//
		// // �ּ�
		// JPanel p14 = new JPanel(new BorderLayout());
		// p14.add("West", addrL);
		// p14.add("East", addrF);
		//
		// // �������
		// JPanel p16 = new JPanel(new BorderLayout());
		// p16.add("West", birthL);
		// p16.add("East", birthF);
		//
		// // �����ҹ�ư
		// JPanel panel7 = new JPanel();
		// panel7.add(transB);
		// panel7.add(cancelB);
		//
		// JPanel p17 = new JPanel(new GridLayout(5, 1, 5, 5));
		// p17.add(p1);
		// p17.add(p5);
		// p17.add(p16);
		// p17.add(p6);
		// p17.add(p12);
		//
		// JPanel p18 = new JPanel(new GridLayout(5, 1, 5, 5));
		// p18.add(p2);
		// p18.add(p3);
		// p18.add(p7);
		// p18.add(ehireDateL);
		// p18.add(epAddrL);
		//
		// JPanel p19 = new JPanel(new GridLayout(1, 2, 25, 10));
		// p19.add(p17);
		// p19.add(p18);
		//
		// JPanel p20 = new JPanel(new BorderLayout());
		// p20.add("Center", p19);
		// p20.add("South", p14);
		// p20.setBorder(infoBorder);
		//
		// JPanel p21 = new JPanel(new BorderLayout());
		// p21.add(sp);
		// p21.setBorder(bBorder);
		//
		// this.setLayout(new BorderLayout());
		//
		// this.add("North", p20);
		// this.add("Center", p21);
		// this.add("South", panel7);

	}

	// public static void main(String[] args) {
	// new BMDesignerJoin();
	// }

}
