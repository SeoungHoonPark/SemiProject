package Customer;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

/*
 * 	�ü����� ������ Ȯ���ϱ� ���� Ŭ����
 */
@SuppressWarnings("serial")
public class BMCustomerDesign /* extends JPanel */ extends JPanel {

	JTable BMCDtable;
	DefaultTableModel BMCDmodel;
	JScrollPane BMCDtsp, BMCDasp;
	JTextArea BMCDarea;
	JComboBox<String> BMCDbox;
	JTextField BMCDField;
	JButton BMCDbtn;

	public BMCustomerDesign() {

		// addWindowListener(new WindowAdapter() {
		// @Override
		// public void windowClosing(WindowEvent e) {
		// System.exit(0);
		// }
		// });

		// try {
		// UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		// } catch (Exception e) {
		// e.printStackTrace();
		// }

		String[] title = { "�ü���¥", "�̸�", "�ü���", "�����", "�ü��ݾ�" };
		BMCDmodel = new DefaultTableModel(title, 0);
		BMCDtable = new JTable(BMCDmodel);
		BMCDtsp = new JScrollPane(BMCDtable);

		BMCDarea = new JTextArea(15, 15);
		BMCDarea.setEditable(false);
		BMCDasp = new JScrollPane(BMCDarea);

		BMCDbox = new JComboBox<String>();
		BMCDbox.addItem("������");
		BMCDbox.addItem("�����̳ʸ�");

		BMCDField = new JTextField();

		BMCDbtn = new JButton("�˻�");

		TitledBorder Bborder = new TitledBorder("�˻�");
		JPanel p1 = new JPanel(new GridLayout(1, 2, 2, 2));
		p1.add(BMCDbox);
		p1.add(BMCDField);

		JPanel p5 = new JPanel(new BorderLayout());
		p5.add("North", p1);
		p5.add("South", BMCDbtn);
		p5.setBorder(Bborder);

		TitledBorder Tborder = new TitledBorder("�ü� ����");

		JPanel p2 = new JPanel(new BorderLayout());
		p2.add(BMCDtsp);
		p2.setBorder(Tborder);

		TitledBorder Aborder = new TitledBorder("�޸�");

		JPanel p3 = new JPanel(new BorderLayout());
		p3.add(BMCDasp);
		p3.setBorder(Aborder);

		JPanel p4 = new JPanel(new BorderLayout());

		p4.setPreferredSize(new Dimension(200, 300));

		p4.add("North", p3);
		p4.add("South", p5);

		setLayout(new BorderLayout());

		add("Center", p2);
		add("East", p4);

		// setSize(810, 565);
		// setVisible(true);
	}

	// public static void main(String[] args) {
	// new BMCustomerDesign();
	// }

}
