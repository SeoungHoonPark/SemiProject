package Customer;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/*
 * 	�������� Ȯ���� ���� ������ ó���� Ŭ����
 *  �˻����� - �̸�, �޴��ȣ, �����̳ʸ� �޺��ڽ��� �����.
 */
@SuppressWarnings("serial")
public class BMCustomerInfo /* extends JPanel */ extends JPanel {
	JButton searchB, registrationB, infoModifyB;
	JTextField nameF, pAddrF, designerF, genderF, mailF, searchF;
	JTable table;
	JComboBox<String> Cbox;
	JLabel nameL, pAddrL, designerL, genderL, mailL;
	DefaultTableModel model;
	Image img = null;

	BMDesignJoin bmdjD;

	public BMCustomerInfo() {
		// this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Toolkit kit = Toolkit.getDefaultToolkit();
		img = kit.getImage("src/Customer/ple1.png");

		// try {
		// UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		// } catch (Exception e) {
		// e.printStackTrace();
		// }

		searchB = new JButton("�˻�");
		registrationB = new JButton("�ü����");
		infoModifyB = new JButton("��������");

		ButtonEvent evt = new ButtonEvent();
		searchB.addActionListener(evt);
		registrationB.addActionListener(evt);
		infoModifyB.addActionListener(evt);

		nameL = new JLabel("�̸�");
		pAddrL = new JLabel("��ȭ��ȣ");
		designerL = new JLabel("�������̳�");
		genderL = new JLabel("����");
		mailL = new JLabel("�̸���");

		nameF = new JTextField(10);
		pAddrF = new JTextField(10);
		designerF = new JTextField(10);
		genderF = new JTextField(10);
		mailF = new JTextField(10);
		searchF = new JTextField(7);

		String[] title = { "�̸�", "��ȭ��ȣ", "�������̳�", "����", "�̸����ּ�" };
		model = new DefaultTableModel(title, 0);
		table = new JTable(model);
		JScrollPane sp = new JScrollPane(table);

		String[] items = { "������", "��ȭ��ȣ", "�����̳ʸ�" };
		Cbox = new JComboBox<String>(items);

		TitledBorder tborder = new TitledBorder("���� ����");
		TitledBorder cborder = new TitledBorder("���� ����");
		TitledBorder mborder = new TitledBorder("��� �� ����");

		JPanel p1 = new JPanel(new GridLayout(5, 1));
		p1.add(nameL);
		p1.add(pAddrL);
		p1.add(designerL);
		p1.add(genderL);
		p1.add(mailL);

		JPanel p2 = new JPanel(new GridLayout(5, 1));
		p2.add(nameF);
		p2.add(pAddrF);
		p2.add(designerF);
		p2.add(genderF);
		p2.add(mailF);

		JPanel p3 = new JPanel(new BorderLayout());
		p3.add("West", p1);
		p3.add("East", p2);
		p3.setBorder(cborder);

		JPanel p4 = new JPanel(new BorderLayout());
		p4.add("North", p3);

		JPanel p5 = new JPanel(new GridLayout(2, 2, 2, 2));
		p5.add(infoModifyB);
		p5.add(registrationB);
		p5.add(Cbox);
		p5.add(searchF);

		JPanel p6 = new JPanel(new BorderLayout());
		p6.add("North", p5);
		p6.add("South", searchB);
		p6.setBorder(mborder);

		JPanel p7 = new JPanel(new BorderLayout());
		p7.add("South", p6);
		p7.add("North", p4);

		JPanel p8 = new JPanel(new BorderLayout());
		p8.add(sp);
		p8.setBorder(tborder);

		setLayout(new BorderLayout());
		add("East", p7);
		add("Center", p8);

		// setSize(720, 520);
		// setVisible(true);
	}

	class ButtonEvent implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == searchB) {

			} else if (e.getSource() == registrationB) {
				bmdjD = new BMDesignJoin();
			} else {

			}
		}

	}

	// public static void main(String[] args) {
	// new BMCustomerInfo();
	// }

	// public void paint(Graphics g){
	// g.drawImage(img, x, y, observer)
	// }
}
