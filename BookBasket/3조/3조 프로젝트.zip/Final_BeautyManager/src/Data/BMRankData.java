package Data;

import java.io.Serializable;

@SuppressWarnings("serial")
public class BMRankData implements Serializable {

	public String code;
	public String name;

	@Override
	public String toString() {
		return name;
	}

}
