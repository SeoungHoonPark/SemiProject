package Data;

import java.io.*;
import java.util.*;

@SuppressWarnings("serial")
public class BMDesignerData implements Serializable {

	public int no;
	public String name;
	public String gender;
	public String birth;
	public String tel;
	public String address;
	public String email;
	public Date joinDate;
	public String rank;
	public String nick;

	@Override
	public String toString() {
		return name;
	}
}
