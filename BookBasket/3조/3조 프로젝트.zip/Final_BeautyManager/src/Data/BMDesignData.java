package Data;

import java.io.Serializable;
import java.sql.*;

@SuppressWarnings("serial")
public class BMDesignData implements Serializable{

	public int no;
	public int customerNo;
//	public String date;
	public Date date;
	public Time time;
	public String name;
	public String pay;
	public String order;
	public String designerCode;
	public String desingerName;
	public String bigo;
	public String makeupName;
	public String kind;
	public String searchText;

	@Override
	public String toString() {
		return name;
	}

}
