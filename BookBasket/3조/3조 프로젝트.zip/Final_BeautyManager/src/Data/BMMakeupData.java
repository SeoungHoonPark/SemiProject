package Data;

import java.io.Serializable;

@SuppressWarnings("serial")
public class BMMakeupData implements Serializable{

	public int code;
	public String name;
	public int pay;

	@Override
	public String toString() {
		return name;
	}
	
}
