package Data;

import java.io.Serializable;

@SuppressWarnings("serial")
public class BMMemberData implements Serializable {

	public String code;
	public String id;
	public String pw;
	public String name;
	public String tel;

	@Override
	public String toString() {
		return id;
	}
}
