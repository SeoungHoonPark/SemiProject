package Data;

import java.io.*;

@SuppressWarnings("serial")
public class BMCustomerData implements Serializable {

	public int no;
	public String name;
	public String tel;
	public String gender;
	public String email;
	public String designerCode;
	public String desingerName;
	public String bigo;
	public String shopCode;
	public String kind;

	@Override
	public String toString() {
		return name;
	}

}
