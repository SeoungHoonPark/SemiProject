package Data;

import java.io.*;
import java.sql.*;

@SuppressWarnings("serial")
public class BMAttendData implements Serializable {

	public int no;
	public Date attdate;
	public Time attTime;
	public String date;
	public String nick;
	public String attcode;

	@Override
	public String toString() {
		return nick;
	}
}
