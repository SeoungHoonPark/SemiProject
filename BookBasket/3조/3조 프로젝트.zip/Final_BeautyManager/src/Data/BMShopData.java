package Data;

import java.io.Serializable;

@SuppressWarnings("serial")
public class BMShopData implements Serializable {

	public String code;
	public String name;
	public String address;
	public String tel;

	@Override
	public String toString() {
		return name;
	}
}
