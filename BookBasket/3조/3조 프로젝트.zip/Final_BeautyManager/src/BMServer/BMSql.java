package BMServer;

public class BMSql {
	// public static final int selectShop = 1001;
	// public static final int selectLogin = 1101;
	// public static final int selectDesigner = 1201;
	// public static final int selectOneCustomer = 1202;
	//
	// public static final int insertCustomer = 2001;

	public static final int selectLogin = 1101;
	public static final int selectOneCustomer = 1102;
	public static final int selectCustomerAll = 1103;
	public static final int selectCustomerName = 1104;
	public static final int selectCustomerTel = 1105;
	public static final int selectCustomerDesigner = 1106;

	public static final int selectDesigner = 1201;
	public static final int selectOneDesigner = 1202;
	public static final int selectNameDesigner = 1203;
	public static final int selectTelDesigner = 1204;
	public static final int selectRankDesigner = 1205;

	public static final int selectDayAttend = 1301;
	public static final int selectDesignerAttend = 1302;
	public static final int selectNowInAttend = 1303;
	public static final int selectNowOutAttend = 1304;

	public static final int selectCustomerMakeup = 1401;
	public static final int selectDesignerMakeup = 1402;
	public static final int selectMakeup = 1403;

	public static final int selectShop = 1901;
	public static final int selectRankInfo = 1902;
	public static final int selectMakeupInfo = 1903;

	public static final int insertCustomer = 2101;
	public static final int insertDesigner = 2201;
	public static final int insertInAttend = 2301;
	public static final int insertOutAttend = 2302;
	public static final int insertMakeup = 2401;

	public static final int updateCustomer = 3101;
	public static final int updateDesigner = 3201;

	public static final int deleteDesigner = 4201;

	public static String getSQL(int code) {
		StringBuffer sqlBuffer = new StringBuffer();
		switch (code) {
		case selectShop: // ü���� �˻�
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	c_Code 	AS CODE, ");
			sqlBuffer.append("	c_Name 	AS NAME, ");
			sqlBuffer.append("	c_Addr 	AS ADDRESS, ");
			sqlBuffer.append("	c_Tel	AS TEL ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMCompany ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append("	c_Out = 'Y' ");
			sqlBuffer.append("ORDER BY ");
			sqlBuffer.append("	c_Name ASC ");
			break;
		case selectLogin: // �α��� ó��
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	a_Code 	AS CODE, ");
			sqlBuffer.append("	a_Id	AS ID, ");
			sqlBuffer.append("	a_Name	AS NAME, ");
			sqlBuffer.append("	a_Tel	AS TEL ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMAdmin ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append("	a_Code = ? ");
			sqlBuffer.append("	AND a_Id = ? ");
			sqlBuffer.append("	AND a_Pw = ? ");
			break;
		case selectDesigner: // �����̳� �˻�
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bmdd_No		AS NO, ");
			sqlBuffer.append("	bmdd_Name	AS NAME, ");
			sqlBuffer.append(" 	bmdd_Tel	AS TEL, ");
			sqlBuffer.append(" 	bmdd_Birth	AS BIRTH, ");
			sqlBuffer.append("	bmdd_Gen	AS GENDER, ");
			sqlBuffer.append(" 	bmdd_Addr	AS ADDRESS, ");
			sqlBuffer.append(" 	bmdd_Date	AS INDATE, ");
			sqlBuffer.append(" 	bmdd_Mail	AS MAIL, ");
			sqlBuffer.append(" 	bmdd_Dname	AS NICK, ");
			sqlBuffer.append(" 	bmdr_Name	AS GRADE ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMDesigner, BMDesignerRank ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append(" 		bmdd_sCode = ? ");
			sqlBuffer.append(" 	AND bmdd_Out = 'N' ");
			sqlBuffer.append("	AND	bmdr_Code = bmdd_Code ");
			sqlBuffer.append("ORDER BY ");
			sqlBuffer.append(" 	bmdd_No ");
			break;
		case selectOneDesigner: // �����̳� ��������
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bmdd_No		AS NO, ");
			sqlBuffer.append("	bmdd_Name	AS NAME, ");
			sqlBuffer.append("	bmdd_Gen	AS GENDER, ");
			sqlBuffer.append("	bmdd_Birth	AS BIRTH, ");
			sqlBuffer.append("	bmdd_Tel	AS TEL, ");
			sqlBuffer.append("	bmdd_Addr	AS ADDRESS, ");
			sqlBuffer.append("	bmdd_Mail	AS MAIL, ");
			sqlBuffer.append("	bmdd_Date	AS INDATE, ");
			sqlBuffer.append("	bmdd_Dname	AS NICK ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMDesigner ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append("		bmdd_Out = 'N' ");
			sqlBuffer.append("	AND	bmdd_sCode = ? ");
			sqlBuffer.append("ORDER BY ");
			sqlBuffer.append("	bmdd_Dname ASC");
			break;
		case insertCustomer: // ���� ���
			sqlBuffer.append("INSERT ");
			sqlBuffer.append("INTO ");
			sqlBuffer.append("	BMCustormer ");
			sqlBuffer.append("VALUES ");
			sqlBuffer.append(
					"	((SELECT NVL(MAX(bmc_No), 0) + 1 FROM BMCustormer), ?, ?, ?, ?, (select bmdd_no from bmdesigner where bmdd_dname=?), ?, ?)");
			break;
		case selectOneCustomer: // ���� ���� �˻�
			// sqlBuffer.append("SELECT ");
			// sqlBuffer.append(" bmc_No AS NO, ");
			// sqlBuffer.append(" bmc_Name AS NAME, ");
			// sqlBuffer.append(" bmc_Tel AS TEL, ");
			// sqlBuffer.append(" bmc_Gen AS GENDER, ");
			// sqlBuffer.append(" bmc_Mail AS MAIL, ");
			// sqlBuffer.append(" bmc_Dno AS CODE, ");
			// sqlBuffer.append(" bmc_Bigo AS BIGO, ");
			// sqlBuffer.append(" bmc_Code AS SHOP ");
			// sqlBuffer.append("FROM ");
			// sqlBuffer.append(" BMCustormer ");
			// sqlBuffer.append("WHERE ");
			// sqlBuffer.append(" bmc_No = ? ");
			// break;
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bmc_No		AS NO, ");
			sqlBuffer.append(" 	bmc_Name	AS NAME, ");
			sqlBuffer.append(" 	bmc_Tel		AS TEL, ");
			sqlBuffer.append(" 	bmc_Gen		AS GENDER, ");
			sqlBuffer.append(" 	bmc_Mail	AS MAIL, ");
			sqlBuffer.append(" 	bmc_Dno		AS CODE, ");
			sqlBuffer.append(" 	bmdd_Dname	AS NICK, ");
			sqlBuffer.append(" 	bmc_Bigo	AS BIGO, ");
			sqlBuffer.append(" 	bmc_Code	AS SHOP ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMCustormer, BMDesigner ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append("		bmc_No = ? ");
			sqlBuffer.append("	AND	bmdd_No = bmc_Dno ");
			break;
		case selectCustomerAll: // ���� ��ü �˻�
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bmc_No		AS NO, ");
			sqlBuffer.append(" 	bmc_Name	AS NAME, ");
			sqlBuffer.append(" 	bmc_Tel		AS TEL, ");
			sqlBuffer.append(" 	bmc_Gen		AS GENDER, ");
			sqlBuffer.append(" 	bmc_Mail	AS MAIL, ");
			sqlBuffer.append(" 	bmc_Dno		AS CODE, ");
			sqlBuffer.append(" 	bmdd_Dname	AS NICK, ");
			sqlBuffer.append(" 	bmc_Bigo	AS BIGO, ");
			sqlBuffer.append(" 	bmc_Code	AS SHOP ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMCustormer, BMDesigner ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append(" 		bmc_Code = ? ");
			sqlBuffer.append("	AND	bmdd_No = bmc_Dno ");
			sqlBuffer.append("ORDER BY ");
			sqlBuffer.append(" 	bmc_No ");
			break;
		case selectCustomerName: // ���� �˻� (�̸�)
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bmc_No		AS NO, ");
			sqlBuffer.append(" 	bmc_Name	AS NAME, ");
			sqlBuffer.append(" 	bmc_Tel		AS TEL, ");
			sqlBuffer.append(" 	bmc_Gen		AS GENDER, ");
			sqlBuffer.append(" 	bmc_Mail	AS MAIL, ");
			sqlBuffer.append(" 	bmc_Dno		AS CODE, ");
			sqlBuffer.append(" 	bmdd_Dname	AS NICK, ");
			sqlBuffer.append(" 	bmc_Bigo	AS BIGO, ");
			sqlBuffer.append(" 	bmc_Code	AS SHOP ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMCustormer, BMDesigner ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append(" 		bmc_Code = ? ");
			sqlBuffer.append("	AND	bmdd_No = bmc_Dno ");
			sqlBuffer.append(" 	AND	bmc_Name LIKE ? ");
			break;
		case selectCustomerTel: // ���� �˻� (��ȭ��ȣ)
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bmc_No		AS NO, ");
			sqlBuffer.append(" 	bmc_Name	AS NAME, ");
			sqlBuffer.append(" 	bmc_Tel		AS TEL, ");
			sqlBuffer.append(" 	bmc_Gen		AS GENDER, ");
			sqlBuffer.append(" 	bmc_Mail	AS MAIL, ");
			sqlBuffer.append(" 	bmc_Dno		AS CODE, ");
			sqlBuffer.append(" 	bmdd_Dname	AS NICK, ");
			sqlBuffer.append(" 	bmc_Bigo	AS BIGO, ");
			sqlBuffer.append(" 	bmc_Code	AS SHOP ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMCustormer, BMDesigner ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append(" 		bmc_Code = ? ");
			sqlBuffer.append("	AND	bmdd_No = bmc_Dno ");
			sqlBuffer.append(" 	AND	bmc_Tel LIKE ? ");
			break;
		case selectCustomerDesigner: // ���� �˻� (�����̳�)
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bmc_No		AS NO, ");
			sqlBuffer.append(" 	bmc_Name	AS NAME, ");
			sqlBuffer.append(" 	bmc_Tel		AS TEL, ");
			sqlBuffer.append(" 	bmc_Gen		AS GENDER, ");
			sqlBuffer.append(" 	bmc_Mail	AS MAIL, ");
			sqlBuffer.append(" 	bmc_Dno		AS CODE, ");
			sqlBuffer.append(" 	bmdd_Dname	AS NICK, ");
			sqlBuffer.append(" 	bmc_Bigo	AS BIGO, ");
			sqlBuffer.append(" 	bmc_Code	AS SHOP ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMCustormer, BMDesigner ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append(" 		bmc_Code = ? ");
			sqlBuffer.append("	AND	bmdd_No = bmc_Dno ");
			sqlBuffer.append(" 	AND	bmdd_Dname LIKE ? ");
			break;
		case updateCustomer: // ���� ���� ����
			sqlBuffer.append("UPDATE ");
			sqlBuffer.append("	BMCustormer ");
			sqlBuffer.append("SET ");
			sqlBuffer.append(" 	bmc_Name = ?, ");
			sqlBuffer.append(" 	bmc_Tel	= ?, ");
			sqlBuffer.append(" 	bmc_Gen	= ?, ");
			sqlBuffer.append(" 	bmc_Mail = ?, ");
			sqlBuffer.append(" 	bmc_Dno = (select bmdd_no from bmdesigner where bmdd_dname=?) ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append(" 	bmc_No = ? ");
			break;
		case selectRankInfo: // ���� �˻�
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bmdr_Code  AS CODE, ");
			sqlBuffer.append("	bmdr_Name  AS NAME ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMDesignerRank ");
			sqlBuffer.append("ORDER BY ");
			sqlBuffer.append("	bmdr_Code ASC ");
			break;
		case selectMakeupInfo: // �ü� ���� �ҷ�����
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bmdk_Code  AS CODE, ");
			sqlBuffer.append("	bmdk_Name  AS NAME, ");
			sqlBuffer.append("	bmdk_Pay  AS PAY ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMDesignKind ");
			sqlBuffer.append("ORDER BY ");
			sqlBuffer.append("	bmdk_Code ASC ");
			break;
		case insertMakeup: // �ü� ���
			sqlBuffer.append("INSERT ");
			sqlBuffer.append("INTO ");
			sqlBuffer.append("	BMDesign ");
			sqlBuffer.append("VALUES ");
			sqlBuffer.append(
					"	((SELECT NVL(MAX(bmd_No), 0) + 1 FROM BMDesign), ?, SYSDATE, ?, ?, (select bmdd_No from BMDesigner where bmdd_dname = ?), ?, (select bmdk_Code from BMDesignKind where bmdk_Name = ?))");
			break;
		case selectMakeup: // �ü� �˻� (��ü)
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bmd_No		AS NO, ");
			sqlBuffer.append("	bmd_Date	AS DDATE, ");
			sqlBuffer.append(" 	bmc_Name	AS NAME, ");
			sqlBuffer.append(" 	bmdk_Name	AS MAKEUPNAME, ");
			sqlBuffer.append(" 	bmdd_Dname	AS NICK, ");
			sqlBuffer.append(" 	bmd_Pay		AS PAY, ");
			sqlBuffer.append(" 	bmd_Bigo	AS BIGO ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMDesign, BMCustormer, BMDesignKind, BMDesigner ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append("		bmd_Cno = bmc_No ");
			sqlBuffer.append("	AND	bmd_Code = bmdk_Code ");
			sqlBuffer.append("	AND	bmd_Dno = bmdd_No ");
			sqlBuffer.append("ORDER BY ");
			sqlBuffer.append("	bmd_No ASC ");
			break;
		case selectCustomerMakeup: // �ü� �˻� (������)
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bmd_No		AS NO, ");
			sqlBuffer.append("	bmd_Date	AS DDATE, ");
			sqlBuffer.append(" 	bmc_Name	AS NAME, ");
			sqlBuffer.append(" 	bmdk_Name	AS MAKEUPNAME, ");
			sqlBuffer.append(" 	bmdd_Dname	AS NICK, ");
			sqlBuffer.append(" 	bmd_Pay		AS PAY, ");
			sqlBuffer.append(" 	bmd_Bigo	AS BIGO ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMDesign, BMCustormer, BMDesignKind, BMDesigner ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append("		bmd_Cno = bmc_No ");
			sqlBuffer.append("	AND	bmd_Code = bmdk_Code ");
			sqlBuffer.append("	AND	bmd_Dno = bmdd_No ");
			sqlBuffer.append("	AND	bmc_Name = ? ");
			sqlBuffer.append("ORDER BY ");
			sqlBuffer.append("	bmd_No ASC ");
			break;
		case selectDesignerMakeup: // �ü� �˻� (�����̳ʸ�)
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bmd_No		AS NO, ");
			sqlBuffer.append("	bmd_Date	AS DDATE, ");
			sqlBuffer.append(" 	bmc_Name	AS NAME, ");
			sqlBuffer.append(" 	bmdk_Name	AS MAKEUPNAME, ");
			sqlBuffer.append(" 	bmdd_Dname	AS NICK, ");
			sqlBuffer.append(" 	bmd_Pay		AS PAY, ");
			sqlBuffer.append(" 	bmd_Bigo	AS BIGO ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMDesign, BMCustormer, BMDesignKind, BMDesigner ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append("		bmd_Cno = bmc_No ");
			sqlBuffer.append("	AND	bmd_Code = bmdk_Code ");
			sqlBuffer.append("	AND	bmd_Dno = bmdd_No ");
			sqlBuffer.append("	AND	bmdd_Dname = ? ");
			sqlBuffer.append("ORDER BY ");
			sqlBuffer.append("	bmd_No ASC ");
			break;
		case insertDesigner: // �����̳� ���
			sqlBuffer.append("INSERT ");
			sqlBuffer.append("INTO ");
			sqlBuffer.append("	BMDesigner ");
			sqlBuffer.append("VALUES ");
			sqlBuffer.append(
					"	((SELECT NVL(MAX(bmdd_No), 0) + 1 FROM BMDesigner), ?, ?, ?, ?, ?, ?, SYSDATE, (select bmdr_code from BMDesignerRank where BMDR_NAME = ?), ?, 'N', null, ?)");
			break;
		case updateDesigner: // �����̳� ���� ����
			sqlBuffer.append("UPDATE ");
			sqlBuffer.append("	BMDesigner ");
			sqlBuffer.append("SET ");
			sqlBuffer.append(" 	bmdd_Name = ?, ");
			sqlBuffer.append(" 	bmdd_Gen	= ?, ");
			sqlBuffer.append(" 	bmdd_Birth	= ?, ");
			sqlBuffer.append(" 	bmdd_Tel	= ?, ");
			sqlBuffer.append(" 	bmdd_Addr	= ?, ");
			sqlBuffer.append(" 	bmdd_Mail	= ?, ");
			sqlBuffer.append(" 	bmdd_Code = (select bmdr_code from BMDesignerRank where BMDR_NAME = ?), ");
			sqlBuffer.append(" 	bmdd_Dname = ? ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append(" 	bmdd_No = ? ");
			break;
		case deleteDesigner: // �����̳� ����
			sqlBuffer.append("UPDATE ");
			sqlBuffer.append("	BMDesigner ");
			sqlBuffer.append("SET ");
			sqlBuffer.append(" 	bmdd_Out = 'Y', ");
			sqlBuffer.append(" 	bmdd_ODate = SYSDATE ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append(" 	bmdd_No = ? ");
			break;
		case selectNameDesigner: // �����̳� �˻� (�̸�)
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bmdd_No		AS NO, ");
			sqlBuffer.append("	bmdd_Name	AS NAME, ");
			sqlBuffer.append(" 	bmdd_Tel	AS TEL, ");
			sqlBuffer.append(" 	bmdd_Birth	AS BIRTH, ");
			sqlBuffer.append("	bmdd_Gen	AS GENDER, ");
			sqlBuffer.append(" 	bmdd_Addr	AS ADDRESS, ");
			sqlBuffer.append(" 	bmdd_Date	AS INDATE, ");
			sqlBuffer.append(" 	bmdd_Mail	AS MAIL, ");
			sqlBuffer.append(" 	bmdd_Dname	AS NICK, ");
			sqlBuffer.append(" 	bmdr_Name	AS GRADE ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMDesigner, BMDesignerRank ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append(" 		bmdd_sCode = ? ");
			sqlBuffer.append("	AND	bmdd_Dname = ? ");
			sqlBuffer.append(" 	AND bmdd_Out = 'N' ");
			sqlBuffer.append("	AND	bmdr_Code = bmdd_Code ");
			sqlBuffer.append("ORDER BY ");
			sqlBuffer.append(" 	bmdd_No ");
			break;
		case selectTelDesigner: // �����̳� �˻� (��ȭ��ȣ)
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bmdd_No		AS NO, ");
			sqlBuffer.append("	bmdd_Name	AS NAME, ");
			sqlBuffer.append(" 	bmdd_Tel	AS TEL, ");
			sqlBuffer.append(" 	bmdd_Birth	AS BIRTH, ");
			sqlBuffer.append("	bmdd_Gen	AS GENDER, ");
			sqlBuffer.append(" 	bmdd_Addr	AS ADDRESS, ");
			sqlBuffer.append(" 	bmdd_Date	AS INDATE, ");
			sqlBuffer.append(" 	bmdd_Mail	AS MAIL, ");
			sqlBuffer.append(" 	bmdd_Dname	AS NICK, ");
			sqlBuffer.append(" 	bmdr_Name	AS GRADE ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMDesigner, BMDesignerRank ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append(" 		bmdd_sCode = ? ");
			sqlBuffer.append("	AND	bmdd_Tel = ? ");
			sqlBuffer.append(" 	AND bmdd_Out = 'N' ");
			sqlBuffer.append("	AND	bmdr_Code = bmdd_Code ");
			sqlBuffer.append("ORDER BY ");
			sqlBuffer.append(" 	bmdd_No ");
			break;
		case selectRankDesigner: // �����̳� �˻� (����)
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bmdd_No		AS NO, ");
			sqlBuffer.append("	bmdd_Name	AS NAME, ");
			sqlBuffer.append(" 	bmdd_Tel	AS TEL, ");
			sqlBuffer.append(" 	bmdd_Birth	AS BIRTH, ");
			sqlBuffer.append("	bmdd_Gen	AS GENDER, ");
			sqlBuffer.append(" 	bmdd_Addr	AS ADDRESS, ");
			sqlBuffer.append(" 	bmdd_Date	AS INDATE, ");
			sqlBuffer.append(" 	bmdd_Mail	AS MAIL, ");
			sqlBuffer.append(" 	bmdd_Dname	AS NICK, ");
			sqlBuffer.append(" 	bmdr_Name	AS GRADE ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMDesigner, BMDesignerRank ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append(" 		bmdd_sCode = ? ");
			sqlBuffer.append("	AND	bmdr_Name = ? ");
			sqlBuffer.append(" 	AND bmdd_Out = 'N' ");
			sqlBuffer.append("	AND	bmdr_Code = bmdd_Code ");
			sqlBuffer.append("ORDER BY ");
			sqlBuffer.append(" 	bmdd_No ");
			break;
		case insertInAttend: // ��� ���
			sqlBuffer.append("INSERT ");
			sqlBuffer.append("INTO ");
			sqlBuffer.append("	BMAttend ");
			sqlBuffer.append("VALUES ");
			sqlBuffer.append(
					"	((SELECT NVL(MAX(bma_No), 0) + 1 FROM BMAttend), SYSDATE, ?, (case when to_char(SYSDATE,'HH24MISS') < '090000' then '1' else '3' end) )");
			break;
		case insertOutAttend: // ��� ���
			sqlBuffer.append("INSERT ");
			sqlBuffer.append("INTO ");
			sqlBuffer.append("	BMAttend ");
			sqlBuffer.append("VALUES ");
			sqlBuffer.append(
					"	((SELECT NVL(MAX(bma_No), 0) + 1 FROM BMAttend), SYSDATE, ?, (case when to_char(SYSDATE,'HH24MISS') < '180000' then '4' else '2' end) )");
			break;
		case selectNowInAttend: // ���ó�¥ ��ٵ����� Ȯ��
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bma_No		AS NO, ");
			sqlBuffer.append("	bma_Date 	AS ADATE, ");
			sqlBuffer.append(" 	bma_Dno 	AS DNO, ");
			sqlBuffer.append(" 	bma_Code 	AS CODE ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMAttend ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append(" 		bma_Dno = ? ");
			sqlBuffer.append("	AND	bma_Code IN(1, 3) ");
			sqlBuffer.append(" 	AND to_char(bma_Date, 'yyyy-mm-dd') = to_char(SYSDATE, 'yyyy-mm-dd') ");
			break;
		case selectNowOutAttend: // ���ó�¥ ��ٵ����� Ȯ��
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bma_No		AS NO, ");
			sqlBuffer.append("	bma_Date 	AS ADATE, ");
			sqlBuffer.append(" 	bma_Dno 	AS DNO, ");
			sqlBuffer.append(" 	bma_Code 	AS CODE ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMAttend ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append(" 		bma_Dno = ? ");
			sqlBuffer.append("	AND	bma_Code IN(2, 4) ");
			sqlBuffer.append(" 	AND to_char(bma_Date, 'yyyy-mm-dd') = to_char(SYSDATE, 'yyyy-mm-dd') ");
			break;
		case selectDayAttend: // �Ϻ� ����� ������ �˻�
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bma_No		AS NO, ");
			sqlBuffer.append("	bma_Date 	AS ADATE, ");
			sqlBuffer.append(" 	bmdd_Dname 	AS NICK, ");
			sqlBuffer.append(" 	bma_Code 	AS CODE ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMAttend, BMDesigner ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append(" 	to_char(bma_Date, 'yyyy-mm-dd') = ? ");
			sqlBuffer.append("	AND	bmdd_No = bma_Dno ");
			sqlBuffer.append("ORDER BY ");
			sqlBuffer.append(" 	bma_Dno, bma_Date ");
			break;
		case selectDesignerAttend: // ���� ����� ������ �г��� �˻�
			sqlBuffer.append("SELECT ");
			sqlBuffer.append("	bma_No		AS NO, ");
			sqlBuffer.append("	bma_Date 	AS ADATE, ");
			sqlBuffer.append(" 	bmdd_Dname 	AS NICK, ");
			sqlBuffer.append(" 	bma_Code 	AS CODE ");
			sqlBuffer.append("FROM ");
			sqlBuffer.append("	BMAttend, BMDesigner ");
			sqlBuffer.append("WHERE ");
			sqlBuffer.append(" 	to_char(bma_Date, 'yyyy-mm') = ? ");
			sqlBuffer.append("	AND	bmdd_No = bma_Dno ");
			sqlBuffer.append("	AND bmdd_Dname = ? ");
			sqlBuffer.append("ORDER BY ");
			sqlBuffer.append(" 	bma_Dno, bma_Date ");
			break;
		}
		return sqlBuffer.toString();
	}
}
