package BMServer;

import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;
import Data.*;

/*
 * 	������ �������ϰ� ����ϸ�ȴ�.
 */
public class BMClientThread extends Thread {

	public BMServerMain main;
	public Socket socket;
	public ObjectInputStream oin;
	public ObjectOutputStream oout;

	public String ip;
	public String shopCode;
	public String managerID;
	public String managerName;

	/**
	 * ������ �Լ�
	 * 
	 * @param main
	 *            mainServer�� ��ȣ���
	 * @param socket
	 *            Ŭ���̾�Ʈ ��� ����
	 * @throws Exception
	 *             ���� ����
	 * @author ���ȯ
	 * @since 2017.02.16
	 * 
	 *        ��������
	 */
	public BMClientThread(BMServerMain main, Socket socket) throws Exception {
		this.main = main;
		this.socket = socket;
		/*
		 * ��Ʈ�� ����
		 */
		oout = new ObjectOutputStream(socket.getOutputStream());
		oin = new ObjectInputStream(socket.getInputStream());
		/*
		 * IP �ޱ�
		 */
		InetAddress inet = socket.getInetAddress();
		ip = inet.getHostAddress();
		this.showStatus(7777, "����");
	}

	/**
	 * ü���� �˻� �Լ�
	 * 
	 * @param data
	 */
	private void selectShop(BMMainData data) {
		this.showStatus(data.protocol, "ü���� �˻�");
		Vector<BMShopData> list = main.dao.getSelectShop();
		BMMainData sData = new BMMainData();
		sData.protocol = 2001;
		sData.anyList = list;

		this.sendData(sData);
	}

	private void loginProcess(BMMainData data) {
		this.showStatus(data.protocol, "�α��� ��û");
		BMMainData sData = main.dao.getSelectLogin(data.memberData);
		if (sData.isSuccess) {
			this.managerID = sData.memberData.id;
			this.managerName = sData.memberData.name;
			this.shopCode = sData.memberData.code;
		}
		Vector<BMDesignerData> list = main.dao.getselectOneDesigner(shopCode);
		sData.protocol = 1110;
		sData.anyList = list;
		this.sendData(sData);
	}

	private void selectCustomer(BMMainData data) {
		this.showStatus(data.protocol, "���� �˻�");
		Vector<BMCustomerData> list = main.dao.selectCustomerAll(shopCode, data.customerData.kind,
				data.customerData.name);
		BMMainData sData = new BMMainData();
		sData.protocol = 1130;
		sData.anyList = list;
		this.sendData(sData);
	}

	private void selectDesigner(BMMainData data) {
		this.showStatus(data.protocol, "�����̳� �˻�");
		Vector<BMDesignerData> list = main.dao.getSelectDesigner(shopCode);
		BMMainData sData = new BMMainData();
		sData.protocol = 1210;
		sData.anyList = list;

		this.sendData(sData);
	}

	private void insertCustomer(BMMainData data) {
		boolean result = main.dao.insertCustomer(data.customerData, shopCode);
		Vector<BMCustomerData> list = main.dao.selectCustomerAll(shopCode, data.customerData.kind,
				data.customerData.name);
		BMMainData sData = new BMMainData();
		sData.protocol = 2110;
		sData.isSuccess = result;
		sData.anyList = list;
		this.sendData(sData);
	}

	private void selectOneDesigner(BMMainData data) {
		this.showStatus(data.protocol, "�г��� �ҷ�����");
		Vector<BMDesignerData> list = main.dao.getselectOneDesigner(shopCode);
		BMMainData sData = new BMMainData();
		sData.protocol = 1220;
		sData.anyList = list;
		this.sendData(sData);
	}

	private void updateCustomer(BMMainData data) {
		this.showStatus(data.protocol, "���� ����");
		boolean result = main.dao.updateCustomer(data.customerData);
		Vector<BMCustomerData> list = main.dao.selectCustomerAll(shopCode, data.customerData.kind,
				data.customerData.name);
		BMMainData sData = new BMMainData();
		sData.protocol = 3110;
		sData.isSuccess = result;
		sData.anyList = list;
		this.sendData(sData);
	}

	private void selectOneCustomer(BMMainData data) {
		BMMainData sData = main.dao.getSelectOneCustomer(data.customerData.no);
		sData.protocol = 2203;
		this.sendData(sData);
	}

	private void selectMakeupInfo(BMMainData data) {
		this.showStatus(data.protocol, "�ü����� �˻�");
		Vector<BMMakeupData> makeuplist = main.dao.getSelectMakeupInfo();
		Vector<BMDesignerData> list = main.dao.getselectOneDesigner(shopCode);
		BMMainData sData = new BMMainData();
		sData.protocol = 1903;
		sData.anyList = list;
		sData.makeupList = makeuplist;
		this.sendData(sData);
	}

	private void insertMakeup(BMMainData data) {
		this.showStatus(data.protocol, "�ü� ���");
		boolean result = main.dao.insertMakeup(data.designData);
		BMMainData sData = new BMMainData();
		sData.protocol = 2410;
		sData.isSuccess = result;
		this.sendData(sData);
	}

	private void selectMakeup(BMMainData data) {
		this.showStatus(data.protocol, "�ü� �˻�");
		Vector<BMDesignData> list = main.dao.selectMakeup(data.designData.kind, data.designData.searchText);
		BMMainData sData = new BMMainData();
		sData.protocol = 1430;
		sData.anyList = list;
		this.sendData(sData);

	}

	private void selectRankInfo(BMMainData data) {
		this.showStatus(data.protocol, "���� �˻�");
		Vector<BMRankData> list = main.dao.getSelectRankInfo();
		BMMainData sData = new BMMainData();
		sData.protocol = 2002;
		sData.anyList = list;

		this.sendData(sData);
	}

	private void insertDesigner(BMMainData data) {
		this.showStatus(data.protocol, "���� ���");
		boolean result = main.dao.insertDesigner(data.designerData, shopCode);
		Vector<BMDesignerData> list = main.dao.getSelectDesigner(shopCode);
		BMMainData sData = new BMMainData();
		sData.protocol = 2210;
		sData.isSuccess = result;
		sData.anyList = list;
		this.sendData(sData);
	}

	private void updateDesigner(BMMainData data) {
		this.showStatus(data.protocol, "�����̳� ����");
		boolean result = main.dao.updateDesigner(data.designerData);
		Vector<BMDesignerData> list = main.dao.getSelectDesigner(shopCode);
		BMMainData sData = new BMMainData();
		sData.protocol = 3210;
		sData.isSuccess = result;
		sData.anyList = list;
		this.sendData(sData);
	}

	private void deleteDesigner(BMMainData data) {
		this.showStatus(data.protocol, "�����̳� ����");
		boolean result = main.dao.deleteDesigner(data.designerData);
		Vector<BMDesignerData> list = main.dao.getSelectDesigner(shopCode);
		BMMainData sData = new BMMainData();
		sData.protocol = 4210;
		sData.isSuccess = result;
		sData.anyList = list;
		this.sendData(sData);
	}

	private void selectNameDesigner(BMMainData data) {
		this.showStatus(data.protocol, "�г��� �˻�");
		Vector<BMDesignerData> list = main.dao.SelectNameDesigner(shopCode, data.designerData);
		BMMainData sData = new BMMainData();
		sData.protocol = 1230;
		sData.anyList = list;

		this.sendData(sData);
	}

	private void selectTelDesigner(BMMainData data) {
		this.showStatus(data.protocol, "��ȭ��ȣ �˻�");
		Vector<BMDesignerData> list = main.dao.SelectTelDesigner(shopCode, data.designerData);
		BMMainData sData = new BMMainData();
		sData.protocol = 1240;
		sData.anyList = list;

		this.sendData(sData);
	}

	private void selectRankDesigner(BMMainData data) {
		this.showStatus(data.protocol, "���� �˻�");
		Vector<BMDesignerData> list = main.dao.SelectRankDesigner(shopCode, data.designerData);
		BMMainData sData = new BMMainData();
		sData.protocol = 1250;
		sData.anyList = list;

		this.sendData(sData);
	}

	private void insertInAttend(BMMainData data) {
		this.showStatus(data.protocol, "�⼮ üũ");
		boolean result = main.dao.insertInAttend(data.designerData);
		BMMainData sData = new BMMainData();
		sData.protocol = 2310;
		sData.isSuccess = result;
		this.sendData(sData);
	}

	private void insertOutAttend(BMMainData data) {
		this.showStatus(data.protocol, "��� üũ");
		boolean result = main.dao.insertOutAttend(data.designerData);
		BMMainData sData = new BMMainData();
		sData.protocol = 2320;
		sData.isSuccess = result;
		this.sendData(sData);
	}

	private void selectDayAttend(BMMainData data) {
		this.showStatus(data.protocol, "�Ϻ� ����� �˻�");
		Vector<BMAttendData> list = main.dao.SelectDayAttend(data.attendData);
		BMMainData sData = new BMMainData();
		sData.protocol = 1310;
		sData.anyList = list;

		this.sendData(sData);
	}

	private void selectDesignerAttend(BMMainData data) {
		this.showStatus(data.protocol, "���� ����� �˻�");
		Vector<BMAttendData> list = main.dao.SelectDesignerAttend(data.attendData);
		BMMainData sData = new BMMainData();
		sData.protocol = 1320;
		sData.anyList = list;

		this.sendData(sData);
	}

	/**
	 * Ŭ���̾�Ʈ ��û�� �޴� ������ �Լ�
	 * 
	 * @author ���ȯ
	 * @since 2017.02.16
	 * 
	 *        ��������
	 */
	public void run() {
		try {
			while (true) {
				BMMainData rData = (BMMainData) oin.readObject();
				switch (rData.protocol) {
				case 1901: // ü���� �˻�
					selectShop(rData);
					break;
				case 1902: // ���� �˻�
					selectRankInfo(rData);
					break;
				case 1101: // �α���
					loginProcess(rData);
					break;
				case 1103: // ���� �˻�
					selectCustomer(rData);
					break;
				case 2101: // ���� ���
					insertCustomer(rData);
					break;
				case 1202: // ������Ͻ� �����̳ʸ� ���� �˻�
					selectOneDesigner(rData);
					break;
				case 3101: // ���� ����
					updateCustomer(rData);
					break;
				case 1102: // ���� �� ���� �˻�
					selectOneCustomer(rData);
					break;
				case 1903: // �ü� ���� �˻�
					selectMakeupInfo(rData);
					break;
				case 2401: // �ü� ���
					insertMakeup(rData);
					break;
				case 1403: // �ü� �˻�
					selectMakeup(rData);
					break;
				case 1201: // �����̳� �˻�
					selectDesigner(rData);
					break;
				case 2201: // �����̳� ���
					insertDesigner(rData);
					break;
				case 3201: // �����̳� ����
					updateDesigner(rData);
					break;
				case 4201: // �����̳� ����
					deleteDesigner(rData);
					break;
				case 1203: // �����̳� �г��� �˻�
					selectNameDesigner(rData);
					break;
				case 1204: // �����̳� ��ȭ��ȣ �˻�
					selectTelDesigner(rData);
					break;
				case 1205: // �����̳� ���� �˻�
					selectRankDesigner(rData);
					break;
				case 2301: // �����̳� ��� ���
					insertInAttend(rData);
					break;
				case 2302: // �����̳� ��� ���
					insertOutAttend(rData);
					break;
				case 1301: // �Ϻ� �����̳� ����� �˻�
					selectDayAttend(rData);
					break;
				case 1302: // ���� �����̳ʺ� ����� �˻�
					selectDesignerAttend(rData);
					break;
				}
			}
		} catch (Exception e) {

		} finally {
			try {
				oin.close();
				oout.close();
				socket.close();
			} catch (Exception e) {
			}
			this.showStatus(7777, "����");
			main.clientList.remove(this);
		}
	}

	/**
	 * Ŭ���̾�Ʈ���� �����͸� �����ϴ� �Լ�
	 * 
	 * @param data
	 *            ������ VO Ŭ����
	 * @author ���ȯ
	 * @since 2017.02.16
	 * 
	 *        ��������
	 */
	private void sendData(BMMainData data) {
		try {
			oout.writeObject(data);
		} catch (Exception e) {
		}
	}

	/**
	 * ��û ���¸� ȭ�鿡 ����ϴ� �Լ�
	 * 
	 * @param data
	 *            ��û ����
	 * @param comment
	 *            ���
	 * @author ���ȯ
	 * @since 2017.02.16
	 * 
	 *        ��������
	 */
	private void showStatus(int protocol, String comment) {
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat form1 = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat form2 = new SimpleDateFormat("hh:mm:ss SSS");
		String[] displayData = new String[5];
		displayData[0] = form1.format(calendar.getTime());
		displayData[1] = form2.format(calendar.getTime());
		displayData[2] = ip;
		displayData[3] = Integer.toString(protocol);
		displayData[4] = comment;

		main.main.tableModel.addRow(displayData);
	}
}
