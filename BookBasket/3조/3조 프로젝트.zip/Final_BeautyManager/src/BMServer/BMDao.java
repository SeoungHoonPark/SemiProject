package BMServer;

import java.sql.*;
import java.util.*;

import Data.*;

public class BMDao {

	public BMJDBCUtil db;
	public Connection con;
	public Statement stmt;
	public PreparedStatement selectShopS, selectLoginS, selectOneCustomerS;
	public PreparedStatement selectCustomerAllS, selectCustomerNameS, selectCustomerTelS, selectCustomerDesignerS;
	public PreparedStatement selectOneDesignerS;
	public PreparedStatement insertCustomerS;
	public PreparedStatement updateCustomerS;

	public PreparedStatement selectMakeupInfoS;
	public PreparedStatement insertMakeupS;
	public PreparedStatement selectMakeupS, selectCustomerMakupS, selectDesignerMakupS;

	public PreparedStatement selectRankInfoS;
	public PreparedStatement insertDesignerS;
	public PreparedStatement updateDesignerS;
	public PreparedStatement deleteDesignerS;
	public PreparedStatement selectDesignerS;
	public PreparedStatement selectNameDesignerS;
	public PreparedStatement selectTelDesignerS;
	public PreparedStatement selectRankDesignerS;

	public PreparedStatement insertInAttendS;
	public PreparedStatement insertOutAttendS;
	public PreparedStatement selectNowInAttendS;
	public PreparedStatement selectNowOutAttendS;

	public PreparedStatement selectDayAttendS;
	public PreparedStatement selectDesignerAttendS;

	public BMDao() {
		db = new BMJDBCUtil();
		con = db.getCON();
		stmt = db.getSTMT(con);
		setStatement();
	}

	private void setStatement() {
		selectShopS = db.getSTMT(con, BMSql.getSQL(BMSql.selectShop));
		selectLoginS = db.getSTMT(con, BMSql.getSQL(BMSql.selectLogin));

		selectCustomerAllS = db.getSTMT(con, BMSql.getSQL(BMSql.selectCustomerAll));
		selectCustomerNameS = db.getSTMT(con, BMSql.getSQL(BMSql.selectCustomerName));
		selectCustomerTelS = db.getSTMT(con, BMSql.getSQL(BMSql.selectCustomerTel));
		selectCustomerDesignerS = db.getSTMT(con, BMSql.getSQL(BMSql.selectCustomerDesigner));

		selectDesignerS = db.getSTMT(con, BMSql.getSQL(BMSql.selectDesigner));
		selectOneCustomerS = db.getSTMT(con, BMSql.getSQL(BMSql.selectOneCustomer));
		selectOneDesignerS = db.getSTMT(con, BMSql.getSQL(BMSql.selectOneDesigner));
		insertCustomerS = db.getSTMT(con, BMSql.getSQL(BMSql.insertCustomer));
		updateCustomerS = db.getSTMT(con, BMSql.getSQL(BMSql.updateCustomer));

		selectMakeupInfoS = db.getSTMT(con, BMSql.getSQL(BMSql.selectMakeupInfo));
		insertMakeupS = db.getSTMT(con, BMSql.getSQL(BMSql.insertMakeup));
		selectMakeupS = db.getSTMT(con, BMSql.getSQL(BMSql.selectMakeup));
		selectCustomerMakupS = db.getSTMT(con, BMSql.getSQL(BMSql.selectCustomerMakeup));
		selectDesignerMakupS = db.getSTMT(con, BMSql.getSQL(BMSql.selectDesignerMakeup));

		selectRankInfoS = db.getSTMT(con, BMSql.getSQL(BMSql.selectRankInfo));
		insertDesignerS = db.getSTMT(con, BMSql.getSQL(BMSql.insertDesigner));
		updateDesignerS = db.getSTMT(con, BMSql.getSQL(BMSql.updateDesigner));
		deleteDesignerS = db.getSTMT(con, BMSql.getSQL(BMSql.deleteDesigner));
		selectNameDesignerS = db.getSTMT(con, BMSql.getSQL(BMSql.selectNameDesigner));
		selectTelDesignerS = db.getSTMT(con, BMSql.getSQL(BMSql.selectTelDesigner));
		selectRankDesignerS = db.getSTMT(con, BMSql.getSQL(BMSql.selectRankDesigner));

		insertInAttendS = db.getSTMT(con, BMSql.getSQL(BMSql.insertInAttend));
		insertOutAttendS = db.getSTMT(con, BMSql.getSQL(BMSql.insertOutAttend));
		selectNowInAttendS = db.getSTMT(con, BMSql.getSQL(BMSql.selectNowInAttend));
		selectNowOutAttendS = db.getSTMT(con, BMSql.getSQL(BMSql.selectNowOutAttend));
		selectDayAttendS = db.getSTMT(con, BMSql.getSQL(BMSql.selectDayAttend));
		selectDesignerAttendS = db.getSTMT(con, BMSql.getSQL(BMSql.selectDesignerAttend));
	}

	public Vector<BMShopData> getSelectShop() {
		ResultSet rs = null;
		Vector<BMShopData> list = new Vector<BMShopData>();
		try {
			rs = selectShopS.executeQuery();
			while (rs.next()) {
				BMShopData data = new BMShopData();
				data.code = rs.getString("CODE");
				data.name = rs.getString("NAME");
				data.address = rs.getString("ADDRESS");
				data.tel = rs.getString("TEL");
				list.add(data);
			}
		} catch (Exception e) {
			System.out.println("ü���� �˻� ���� = " + e);
		} finally {
			db.close(rs);
		}
		return list;
	}

	public BMMainData getSelectLogin(BMMemberData data) {
		ResultSet rs = null;
		BMMainData rData = new BMMainData();
		try {
			selectLoginS.setString(1, data.code);
			selectLoginS.setString(2, data.id);
			selectLoginS.setString(3, data.pw);
			rs = selectLoginS.executeQuery();
			if (rs.next()) {
				BMMemberData temp = new BMMemberData();
				temp.code = rs.getString("CODE");
				temp.id = rs.getString("ID");
				temp.name = rs.getString("NAME");
				temp.tel = rs.getString("TEL");
				rData.isSuccess = true;
				rData.memberData = temp;
			} else {
				rData.isSuccess = false;
			}
		} catch (Exception e) {
			System.out.println("�α��� ó�� ���� = " + e);
		} finally {
			db.close(rs);
		}
		return rData;
	}

	public Vector<BMCustomerData> selectCustomerAll(String shopCode, String kind, String data) {
		ResultSet rs = null;
		Vector<BMCustomerData> list = new Vector<BMCustomerData>();
		try {
			if (kind.equals("��ü")) {
				selectCustomerAllS.setString(1, shopCode);
				rs = selectCustomerAllS.executeQuery();
			} else if (kind.equals("������")) {
				selectCustomerNameS.setString(1, shopCode);
				selectCustomerNameS.setString(2, "%" + data + "%");
				rs = selectCustomerNameS.executeQuery();
			} else if (kind.equals("��ȭ��ȣ")) {
				selectCustomerTelS.setString(1, shopCode);
				selectCustomerTelS.setString(2, "%" + data + "%");
				rs = selectCustomerTelS.executeQuery();
			} else {
				selectCustomerDesignerS.setString(1, shopCode);
				selectCustomerDesignerS.setString(2, "%" + data + "%");
				rs = selectCustomerDesignerS.executeQuery();
			}
			while (rs.next()) {
				BMCustomerData temp = new BMCustomerData();
				temp.no = rs.getInt("NO");
				temp.name = rs.getString("NAME");
				temp.tel = rs.getString("TEL");
				temp.gender = rs.getString("GENDER");
				temp.email = rs.getString("MAIL");
				temp.designerCode = rs.getString("CODE");
				temp.desingerName = rs.getString("NICK");
				temp.bigo = rs.getString("BIGO");
				temp.shopCode = rs.getString("SHOP");
				list.add(temp);
			}
		} catch (Exception e) {
			System.out.println("���� ��ü �˻� ó�� ���� = " + e);
		} finally {
			db.close(rs);
		}
		return list;
	}

	public Vector<BMDesignerData> getselectOneDesigner(String code) {
		ResultSet rs = null;
		Vector<BMDesignerData> list = new Vector<BMDesignerData>();
		try {
			selectOneDesignerS.setString(1, code);
			rs = selectOneDesignerS.executeQuery();
			while (rs.next()) {
				BMDesignerData data = new BMDesignerData();
				data.no = rs.getInt("NO");
				data.nick = rs.getString("NICK");
				list.add(data);
			}
		} catch (Exception e) {
			System.out.println("�����̳� �ε� ���� = " + e);
		} finally {
			db.close(rs);
		}
		return list;
	}

	public Vector<BMDesignerData> getSelectDesigner(String code) {
		ResultSet rs = null;
		Vector<BMDesignerData> list = new Vector<BMDesignerData>();
		try {
			selectDesignerS.setString(1, code);
			rs = selectDesignerS.executeQuery();
			while (rs.next()) {
				BMDesignerData data = new BMDesignerData();
				data.no = rs.getInt("NO");
				data.name = rs.getString("NAME");
				data.tel = rs.getString("TEL");
				data.birth = rs.getString("BIRTH");
				data.gender = rs.getString("GENDER");
				data.address = rs.getString("ADDRESS");
				data.joinDate = rs.getDate("INDATE");
				data.email = rs.getString("MAIL");
				data.nick = rs.getString("NICK");
				data.rank = rs.getString("GRADE");
				list.add(data);
				// Object[] o = new Object[10];
				// o[0] = rs.getInt("NO");
				// o[1] = rs.getString("NAME");
				// o[2] = rs.getString("TEL");
				// o[3] = rs.getString("BIRTH");
				// o[4] = rs.getString("GENDER");
				// o[5] = rs.getString("ADDRESS");
				// o[6] = rs.getString("INDATE");
				// o[7] = rs.getString("MAIL");
				// o[8] = rs.getString("NICK");
				// o[9] = rs.getString("GRADE");
				// list.add(o);
			}
		} catch (Exception e) {
			System.out.println("�����̳� �˻� ���� = " + e);
		} finally {
			db.close(rs);
		}
		return list;
	}

	public boolean insertCustomer(BMCustomerData data, String code) {
		try {
			insertCustomerS.setString(1, data.name);
			insertCustomerS.setString(2, data.tel);
			insertCustomerS.setString(3, data.gender);
			insertCustomerS.setString(4, data.email);
			insertCustomerS.setString(5, data.desingerName);
			insertCustomerS.setString(6, data.bigo);
			insertCustomerS.setString(7, code);
			insertCustomerS.execute();
			return true;
		} catch (Exception e) {
			System.out.println("���� ��� ���� " + e);
			return false;
		}
	}

	public BMMainData getSelectOneCustomer(int no) {
		ResultSet rs = null;
		BMMainData rData = new BMMainData();
		try {
			selectOneCustomerS.setInt(1, no);
			rs = selectOneCustomerS.executeQuery();
			if (rs.next()) {
				BMCustomerData temp = new BMCustomerData();
				temp.no = rs.getInt("NO");
				temp.name = rs.getString("NAME");
				temp.tel = rs.getString("TEL");
				temp.gender = rs.getString("GENDER");
				temp.email = rs.getString("MAIL");
				temp.designerCode = rs.getString("CODE");
				temp.desingerName = rs.getString("NICK");
				temp.bigo = rs.getString("BIGO");
				temp.shopCode = rs.getString("SHOP");

				rData.isSuccess = true;
				rData.customerData = temp;
			} else {
				rData.isSuccess = false;
			}
		} catch (Exception e) {
			System.out.println("���� �� ���� �˻� ó�� ���� = " + e);
		} finally {
			db.close(rs);
		}
		return rData;
	}

	public boolean updateCustomer(BMCustomerData data) {
		try {
			updateCustomerS.setString(1, data.name);
			updateCustomerS.setString(2, data.tel);
			updateCustomerS.setString(3, data.gender);
			updateCustomerS.setString(4, data.email);
			updateCustomerS.setString(5, data.desingerName);
			updateCustomerS.setInt(6, data.no);
			updateCustomerS.execute();
			return true;
		} catch (Exception e) {
			System.out.println("���� ������Ʈ ó�� ���� " + e);
			return false;
		}
	}

	public Vector<BMMakeupData> getSelectMakeupInfo() {
		ResultSet rs = null;
		Vector<BMMakeupData> list = new Vector<BMMakeupData>();
		try {
			rs = selectMakeupInfoS.executeQuery();
			while (rs.next()) {
				BMMakeupData data = new BMMakeupData();
				data.code = rs.getInt("CODE");
				data.name = rs.getString("NAME");
				data.pay = rs.getInt("PAY");
				list.add(data);
			}
		} catch (Exception e) {
			System.out.println("�ü� ���� �ҷ����� ���� = " + e);
		} finally {
			db.close(rs);
		}
		return list;
	}

	public boolean insertMakeup(BMDesignData data) {
		try {
			insertMakeupS.setInt(1, data.customerNo);
			insertMakeupS.setString(2, data.order);
			insertMakeupS.setString(3, data.bigo);
			insertMakeupS.setString(4, data.desingerName);
			insertMakeupS.setString(5, data.pay);
			insertMakeupS.setString(6, data.makeupName);
			insertMakeupS.execute();
			return true;
		} catch (Exception e) {
			System.out.println("�ü� ��� ���� " + e);
			return false;
		}
	}

	public Vector<BMDesignData> selectMakeup(String kind, String data) {
		ResultSet rs = null;
		Vector<BMDesignData> list = new Vector<BMDesignData>();
		try {
			if (kind.equals("��ü")) {
				rs = selectMakeupS.executeQuery();
			} else if (kind.equals("������")) {
				selectCustomerMakupS.setString(1, data);
				rs = selectCustomerMakupS.executeQuery();
			} else {
				selectDesignerMakupS.setString(1, data);
				rs = selectDesignerMakupS.executeQuery();
			}
			while (rs.next()) {
				BMDesignData temp = new BMDesignData();
				temp.no = rs.getInt("NO");
				temp.date = rs.getDate("DDATE");
				temp.time = rs.getTime("DDATE");
				temp.name = rs.getString("NAME");
				temp.makeupName = rs.getString("MAKEUPNAME");
				temp.desingerName = rs.getString("NICK");
				temp.pay = rs.getString("PAY");
				temp.bigo = rs.getString("BIGO");
				list.add(temp);
			}
		} catch (Exception e) {
			System.out.println("�ü� �˻� ó�� ���� = " + e);
		} finally {
			db.close(rs);
		}
		return list;

	}

	public Vector<BMRankData> getSelectRankInfo() {
		ResultSet rs = null;
		Vector<BMRankData> list = new Vector<BMRankData>();
		try {
			rs = selectRankInfoS.executeQuery();
			while (rs.next()) {
				BMRankData data = new BMRankData();
				data.code = rs.getString("CODE");
				data.name = rs.getString("NAME");
				list.add(data);
			}
		} catch (Exception e) {
			System.out.println("���� �˻� ���� = " + e);
		} finally {
			db.close(rs);
		}
		return list;
	}

	public boolean insertDesigner(BMDesignerData data, String code) {
		try {
			insertDesignerS.setString(1, data.name);
			insertDesignerS.setString(2, data.gender);
			insertDesignerS.setString(3, data.birth);
			insertDesignerS.setString(4, data.tel);
			insertDesignerS.setString(5, data.address);
			insertDesignerS.setString(6, data.email);
			insertDesignerS.setString(7, data.rank);
			insertDesignerS.setString(8, data.nick);
			insertDesignerS.setString(9, code);
			insertDesignerS.execute();
			return true;
		} catch (Exception e) {
			System.out.println("�����̳� ��� ó�� ���� " + e);
			return false;
		}
	}

	public boolean updateDesigner(BMDesignerData data) {
		try {
			updateDesignerS.setString(1, data.name);
			updateDesignerS.setString(2, data.gender);
			updateDesignerS.setString(3, data.birth);
			updateDesignerS.setString(4, data.tel);
			updateDesignerS.setString(5, data.address);
			updateDesignerS.setString(6, data.email);
			updateDesignerS.setString(7, data.rank);
			updateDesignerS.setString(8, data.nick);
			updateDesignerS.setInt(9, data.no);
			updateDesignerS.execute();
			return true;
		} catch (Exception e) {
			System.out.println("�����̳� ������Ʈ ó�� ���� " + e);
			return false;
		}
	}

	public boolean deleteDesigner(BMDesignerData data) {
		try {
			deleteDesignerS.setInt(1, data.no);
			deleteDesignerS.execute();
			return true;
		} catch (Exception e) {
			System.out.println("�����̳� ���� ó�� ���� " + e);
			return false;
		}
	}

	public Vector<BMDesignerData> SelectNameDesigner(String code, BMDesignerData data) {
		ResultSet rs = null;
		Vector<BMDesignerData> list = new Vector<BMDesignerData>();
		try {
			selectNameDesignerS.setString(1, code);
			selectNameDesignerS.setString(2, data.nick);
			rs = selectNameDesignerS.executeQuery();
			while (rs.next()) {
				BMDesignerData data1 = new BMDesignerData();
				data1.no = rs.getInt("NO");
				data1.name = rs.getString("NAME");
				data1.tel = rs.getString("TEL");
				data1.birth = rs.getString("BIRTH");
				data1.gender = rs.getString("GENDER");
				data1.address = rs.getString("ADDRESS");
				data1.joinDate = rs.getDate("INDATE");
				data1.email = rs.getString("MAIL");
				data1.nick = rs.getString("NICK");
				data1.rank = rs.getString("GRADE");
				list.add(data1);
			}
		} catch (Exception e) {
			System.out.println("�����̳� �˻� ���� = " + e);
		} finally {
			db.close(rs);
		}
		return list;
	}

	public Vector<BMDesignerData> SelectTelDesigner(String code, BMDesignerData data) {
		ResultSet rs = null;
		Vector<BMDesignerData> list = new Vector<BMDesignerData>();
		try {
			selectTelDesignerS.setString(1, code);
			selectTelDesignerS.setString(2, data.tel);
			rs = selectTelDesignerS.executeQuery();
			while (rs.next()) {
				BMDesignerData data1 = new BMDesignerData();
				data1.no = rs.getInt("NO");
				data1.name = rs.getString("NAME");
				data1.tel = rs.getString("TEL");
				data1.birth = rs.getString("BIRTH");
				data1.gender = rs.getString("GENDER");
				data1.address = rs.getString("ADDRESS");
				data1.joinDate = rs.getDate("INDATE");
				data1.email = rs.getString("MAIL");
				data1.nick = rs.getString("NICK");
				data1.rank = rs.getString("GRADE");
				list.add(data1);
			}
		} catch (Exception e) {
			System.out.println("�����̳� �˻� ���� = " + e);
		} finally {
			db.close(rs);
		}
		return list;
	}

	public Vector<BMDesignerData> SelectRankDesigner(String code, BMDesignerData data) {
		ResultSet rs = null;
		Vector<BMDesignerData> list = new Vector<BMDesignerData>();
		try {
			selectRankDesignerS.setString(1, code);
			selectRankDesignerS.setString(2, data.rank);
			rs = selectRankDesignerS.executeQuery();
			while (rs.next()) {
				BMDesignerData data1 = new BMDesignerData();
				data1.no = rs.getInt("NO");
				data1.name = rs.getString("NAME");
				data1.tel = rs.getString("TEL");
				data1.birth = rs.getString("BIRTH");
				data1.gender = rs.getString("GENDER");
				data1.address = rs.getString("ADDRESS");
				data1.joinDate = rs.getDate("INDATE");
				data1.email = rs.getString("MAIL");
				data1.nick = rs.getString("NICK");
				data1.rank = rs.getString("GRADE");
				list.add(data1);
			}
		} catch (Exception e) {
			System.out.println("�����̳� �˻� ���� = " + e);
		} finally {
			db.close(rs);
		}
		return list;
	}

	public boolean insertInAttend(BMDesignerData data) {
		ResultSet rs = null;
		try {
			selectNowInAttendS.setInt(1, data.no);
			rs = selectNowInAttendS.executeQuery();
			if (rs.next() == true) {
				return false;
			} else {
				insertInAttendS.setInt(1, data.no);
				insertInAttendS.execute();
				return true;
			}
		} catch (Exception e) {
			System.out.println("�����̳� ��� ó�� ���� " + e);
			return false;
		}
	}

	public boolean insertOutAttend(BMDesignerData data) {
		ResultSet rs = null;
		try {
			selectNowOutAttendS.setInt(1, data.no);
			rs = selectNowOutAttendS.executeQuery();
			if (rs.next() == true) {
				return false;
			} else {
				insertOutAttendS.setInt(1, data.no);
				insertOutAttendS.execute();
				return true;
			}
		} catch (Exception e) {
			System.out.println("�����̳� ��� ó�� ���� " + e);
			return false;
		}
	}

	public Vector<BMAttendData> SelectDayAttend(BMAttendData data) {
		ResultSet rs = null;
		Vector<BMAttendData> list = new Vector<BMAttendData>();
		try {
			selectDayAttendS.setDate(1, data.attdate);
			rs = selectDayAttendS.executeQuery();
			while (rs.next()) {
				BMAttendData data1 = new BMAttendData();
				data1.no = rs.getInt("NO");
				data1.attdate = rs.getDate("ADATE");
				data1.attTime = rs.getTime("ADATE");
				data1.nick = rs.getString("NICK");
				data1.attcode = rs.getString("CODE");
				list.add(data1);
			}
		} catch (Exception e) {
			System.out.println("�Ϻ� ����� �˻� ���� = " + e);
		} finally {
			db.close(rs);
		}
		return list;
	}

	public Vector<BMAttendData> SelectDesignerAttend(BMAttendData data) {
		ResultSet rs = null;
		Vector<BMAttendData> list = new Vector<BMAttendData>();
		try {
			selectDesignerAttendS.setString(1, data.date);
			selectDesignerAttendS.setString(2, data.nick);
			rs = selectDesignerAttendS.executeQuery();
			while (rs.next()) {
				BMAttendData data1 = new BMAttendData();
				data1.no = rs.getInt("NO");
				data1.attdate = rs.getDate("ADATE");
				data1.attTime = rs.getTime("ADATE");
				data1.nick = rs.getString("NICK");
				data1.attcode = rs.getString("CODE");
				list.add(data1);
			}
		} catch (Exception e) {
			System.out.println("���� �����̳ʺ� �˻� ���� = " + e);
		} finally {
			db.close(rs);
		}
		return list;
	}

}
