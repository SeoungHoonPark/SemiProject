package BMServer;

import java.sql.*;

public class BMJDBCUtil {
	public BMJDBCUtil() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (Exception e) {
			System.out.println("����̹� �ε� ���� = " + e);
		}
	}

	public Connection getCON() {
		Connection con = null;
		try {
			String url = "jdbc:oracle:thin:@localhost:1521:orcl";
			con = DriverManager.getConnection(url, "scott", "tiger");
		} catch (Exception e) {
			System.out.println("���� ���� = " + e);
		}
		return con;
	}

	public Statement getSTMT(Connection con) {
		Statement stmt = null;
		try {
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
		} catch (Exception e) {
			System.out.println("Statement ���� ���� = " + e);
		}
		return stmt;
	}

	public PreparedStatement getSTMT(Connection con, String sql) {
		PreparedStatement stmt = null;
		try {
			stmt = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
		} catch (Exception e) {
			System.out.println("PreparedStatement ���� ���� = " + e);
		}
		return stmt;
	}

	public void close(Object o) {
		try {
			if (o instanceof Connection) {
				((Connection) o).close();
			} else if (o instanceof Statement) {
				((Statement) o).close();
			} else if (o instanceof PreparedStatement) {
				((PreparedStatement) o).close();
			} else if (o instanceof ResultSet) {
				((ResultSet) o).close();
			}
		} catch (Exception e) {
		}
	}
}
