package BMServer;

import javax.swing.*;
import javax.swing.table.*;

@SuppressWarnings("serial")
public class BMServerManager extends JFrame {

	public BMServerMain server;
	public JTable displayTable;
	public DefaultTableModel tableModel;
	public JLabel statusLabel;

	public BMServerManager() {
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		String[] title = { "������", "���ӽð�", "����IP", "��û����", "���" };
		tableModel = new DefaultTableModel(title, 0);
		displayTable = new JTable(tableModel);
		JScrollPane sp = new JScrollPane(displayTable);

		DefaultTableCellRenderer dtcr = new DefaultTableCellRenderer();
		dtcr.setHorizontalAlignment(SwingConstants.CENTER);
		TableColumnModel tmodel = displayTable.getColumnModel();

		for (int i = 0; i < tmodel.getColumnCount(); i++) {
			tmodel.getColumn(i).setCellRenderer(dtcr);
		}

		statusLabel = new JLabel("<html><font color='red'>������ �⵿�߿� �ֽ��ϴ�.</font></html>", JLabel.CENTER);

		this.add("North", statusLabel);
		this.add("Center", sp);

		ImageIcon icon = new ImageIcon("src/Manager/TitleIcon.png");
		this.setIconImage(icon.getImage());
		this.setTitle("BeautyManagerServer");
		this.setSize(700, 800);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		server = new BMServerMain(this);
		server.start();
	}

	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel("com.jtattoo.plaf.mcwin.McWinLookAndFeel");
		} catch (Exception e) {
			e.printStackTrace();
		}
		new BMServerManager();
	}

}
