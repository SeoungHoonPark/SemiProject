package Receive;

import java.awt.*;

import javax.swing.*;
import javax.swing.table.*;

import Data.*;
import Manager.*;

public class BMReceiveThread extends Thread {
	public BMMain main;

	public BMReceiveThread(BMMain m) {
		main = m;
	}

	void setShopList(BMMainData data) {
		main.loginDlg.cpbox.removeAllItems();
		for (int i = 0; i < data.anyList.size(); i++) {
			main.loginDlg.cpbox.addItem(data.anyList.get(i));
		}
		main.loginDlg.setVisible(true);
	}

	void setLogin(BMMainData data) {
		if (data.isSuccess == true) {
			main.bmcmP.bmciP.Dbox.removeAllItems();
			main.bmcmP.bmciP.Dbox.addItem("");
			for (int i = 0; i < data.anyList.size(); i++) {
				BMDesignerData Ddata = (BMDesignerData) data.anyList.get(i);
				main.bmcmP.bmciP.Dbox.addItem(Ddata.nick);
			}
			main.thisDisplay();
		} else {
			JOptionPane.showMessageDialog(main, "�α��� ������ Ʋ�Ƚ��ϴ� �ٽ� �Է��ϼ���.");
		}
	}

	void setSelectCustomer(BMMainData data) {

		main.bmcmP.bmciP.nameF.setText("");
		main.bmcmP.bmciP.pAddrF.setText("");
		main.bmcmP.bmciP.Dbox.setSelectedItem("");
		main.bmcmP.bmciP.genderF.setText("");
		main.bmcmP.bmciP.mailF.setText("");
		main.bmcmP.bmciP.searchF.setText("");

		int rows = main.bmcmP.bmciP.model.getRowCount();
		for (int i = 0; i < rows; i++) {
			main.bmcmP.bmciP.model.removeRow(0);
		}

		for (int i = 0; i < data.anyList.size(); i++) {
			BMCustomerData temp = (BMCustomerData) data.anyList.get(i);
			main.bmcmP.bmciP.model.addRow(new Object[5]);
			main.bmcmP.bmciP.table.setValueAt(temp.no, i, 0);
			main.bmcmP.bmciP.table.setValueAt(temp, i, 1);
			main.bmcmP.bmciP.table.setValueAt(temp.tel, i, 2);
			main.bmcmP.bmciP.table.setValueAt(temp.desingerName, i, 3);
			main.bmcmP.bmciP.table.setValueAt(temp.gender, i, 4);
			main.bmcmP.bmciP.table.setValueAt(temp.email, i, 5);
		}

		resizeColumnWidth(main.bmcmP.bmciP.table);

		main.bmcmP.bmciP.sp.getVerticalScrollBar().setValue(main.bmcmP.bmciP.sp.getVerticalScrollBar().getMaximum());

		int row = main.bmcmP.bmcdP.BMCDmodel.getRowCount();
		if (row == -1) {
			return;
		}
		for (int i = 0; i < row; i++) {
			main.bmcmP.bmcdP.BMCDmodel.removeRow(0);
		}

//		if (data.designList != null) {
//			for (int i = 0; i < data.designList.size(); i++) {
//				BMDesignData dData = (BMDesignData) data.designList.get(i);
//				main.bmcmP.bmcdP.BMCDmodel.addRow(new Object[6]);
//				main.bmcmP.bmcdP.BMCDmodel.setValueAt(dData.no, i, 0);
//				main.bmcmP.bmcdP.BMCDmodel.setValueAt(dData.date + " " + dData.time, i, 1);
//				main.bmcmP.bmcdP.BMCDmodel.setValueAt(dData, i, 2);
//				main.bmcmP.bmcdP.BMCDmodel.setValueAt(dData.makeupName, i, 3);
//				main.bmcmP.bmcdP.BMCDmodel.setValueAt(dData.desingerName, i, 4);
//				main.bmcmP.bmcdP.BMCDmodel.setValueAt(dData.pay, i, 5);
//			}
//		}
	}

	void setSelectOneDesigner(BMMainData data) {

		main.bmcmP.bmcjD.designerCB.removeAllItems();

		for (int i = 0; i < data.anyList.size(); i++) {
			BMDesignerData Ddata = (BMDesignerData) data.anyList.get(i);
			main.bmcmP.bmcjD.designerCB.addItem(Ddata.nick);
		}

		main.bmcmP.bmcjD.setVisible(true);
	}

	void setInsertCustomer(BMMainData data) {
		if (data.isSuccess == true) {
			main.bmcmP.bmcjD.setVisible(false);
			setSelectCustomer(data);
		} else {
			JOptionPane.showMessageDialog(main, "���� ��Ͽ� �����Ͽ����ϴ�.");
		}
	}

	void setUpdateCustomer(BMMainData data) {
		if (data.isSuccess == true) {
			setSelectCustomer(data);
		} else {
			JOptionPane.showMessageDialog(main, "���� ������ �����Ͽ����ϴ�.");
		}
	}

	void setSelectMakeupInfo(BMMainData data) {
		main.bmcmP.bmciP.bmdjD.procedureC1.removeAllItems();
		for (int i = 0; i < data.makeupList.size(); i++) {
			main.bmcmP.bmciP.bmdjD.procedureC1.addItem(data.makeupList.get(i));
		}

		for (int i = 0; i < data.anyList.size(); i++) {
			BMDesignerData Ddata = (BMDesignerData) data.anyList.get(i);
			main.bmcmP.bmciP.bmdjD.designerC.addItem(Ddata.nick);
		}

		main.bmcmP.bmciP.bmdjD.designerC.setSelectedItem(main.bmcmP.bmciP.Dbox.getSelectedItem());
	}

	void setInsertMakeup(BMMainData data) {
		if (data.isSuccess == true) {
			main.bmcmP.bmciP.bmdjD.setVisible(false);
			JOptionPane.showMessageDialog(main, "�ü� ����� �Ǿ����ϴ�.");
		} else {
			JOptionPane.showMessageDialog(main, "�ü� ��Ͽ� �����Ͽ����ϴ�.");
		}
	}

	void setSeletMakeup(BMMainData data) {

		int row = main.bmcmP.bmcdP.BMCDmodel.getRowCount();
		if (row == -1) {
			return;
		}
		for (int i = 0; i < row; i++) {
			main.bmcmP.bmcdP.BMCDmodel.removeRow(0);
		}

		int size = data.anyList.size();

		for (int i = 0; i < size; i++) {
			BMDesignData dData = (BMDesignData) data.anyList.get(i);
			main.bmcmP.bmcdP.BMCDmodel.addRow(new Object[6]);
			main.bmcmP.bmcdP.BMCDmodel.setValueAt(dData.no, i, 0);
			main.bmcmP.bmcdP.BMCDmodel.setValueAt(dData.date + " " + dData.time, i, 1);
			main.bmcmP.bmcdP.BMCDmodel.setValueAt(dData, i, 2);
			main.bmcmP.bmcdP.BMCDmodel.setValueAt(dData.makeupName, i, 3);
			main.bmcmP.bmcdP.BMCDmodel.setValueAt(dData.desingerName, i, 4);
			main.bmcmP.bmcdP.BMCDmodel.setValueAt(dData.pay, i, 5);
		}

		resizeColumnWidth(main.bmcmP.bmcdP.BMCDtable);

		main.bmcmP.bmcdP.BMCDtsp.getVerticalScrollBar()
				.setValue(main.bmcmP.bmcdP.BMCDtsp.getVerticalScrollBar().getMaximum());

	}

	void setRankList(BMMainData data) {
		main.bmdmP.bmdjD.rankC.removeAllItems();
		for (int i = 0; i < data.anyList.size(); i++) {
			main.bmdmP.bmdjD.rankC.addItem(data.anyList.get(i));
		}
		// main.loginDlg.setVisible(true);
	}

	void setInsertDesigner(BMMainData data) {
		if (data.isSuccess == true) {
			main.bmdmP.bmdjD.setVisible(false);
			setSelectDesigner(data);
		} else {
			JOptionPane.showMessageDialog(main, "�����̳� ��Ͽ� �����Ͽ����ϴ�.");
		}
	}

	void setSelectDesigner(BMMainData data) {

		int row = main.bmdmP.bmdiP.model.getRowCount();
		if (row == -1) {
			return;
		}
		for (int i = 0; i < row; i++) {
			main.bmdmP.bmdiP.model.removeRow(0);
		}

		int size = data.anyList.size();

		for (int i = 0; i < size; i++) {
			BMDesignerData Ddata = (BMDesignerData) data.anyList.get(i);
			main.bmdmP.bmdiP.model.addRow(new Object[10]);
			main.bmdmP.bmdiP.model.setValueAt(Ddata.no, i, 0);
			main.bmdmP.bmdiP.model.setValueAt(Ddata, i, 1);
			main.bmdmP.bmdiP.model.setValueAt(Ddata.tel, i, 2);
			main.bmdmP.bmdiP.model.setValueAt(Ddata.birth, i, 3);
			main.bmdmP.bmdiP.model.setValueAt(Ddata.gender, i, 4);
			main.bmdmP.bmdiP.model.setValueAt(Ddata.address, i, 5);
			main.bmdmP.bmdiP.model.setValueAt(Ddata.joinDate, i, 6);
			main.bmdmP.bmdiP.model.setValueAt(Ddata.email, i, 7);
			main.bmdmP.bmdiP.model.setValueAt(Ddata.nick, i, 8);
			main.bmdmP.bmdiP.model.setValueAt(Ddata.rank, i, 9);
		}

		resizeColumnWidth(main.bmdmP.bmdiP.table);

		main.bmdmP.bmdiP.sp.getVerticalScrollBar().setValue(main.bmdmP.bmdiP.sp.getVerticalScrollBar().getMaximum());
	}

	void setUpdateDesigner(BMMainData data) {
		if (data.isSuccess == true) {
			setSelectDesigner(data);
			textRemove();
		} else {
			JOptionPane.showMessageDialog(main, "�����̳� ������ �����Ͽ����ϴ�.");
		}
	}

	void setDeleteDesigner(BMMainData data) {
		if (data.isSuccess == true) {
			setSelectDesigner(data);
			textRemove();
		} else {
			JOptionPane.showMessageDialog(main, "�����̳� ������ �����Ͽ����ϴ�.");
		}
	}

	void setSelectNameDesigner(BMMainData data) {
		setSelectDesigner(data);
		textRemove();
	}

	void setSelectTelDesigner(BMMainData data) {
		setSelectDesigner(data);
		textRemove();
	}

	void setSelectRankDesigner(BMMainData data) {
		setSelectDesigner(data);
		textRemove();
	}

	void setInsertInAttend(BMMainData data) {
		if (data.isSuccess == true) {
			JOptionPane.showMessageDialog(main, "��� ����� �Ǿ����ϴ�.");
		} else {
			JOptionPane.showMessageDialog(main, "�̹� ��� ó���� �Ǿ����ϴ�.");
		}
	}

	void setInsertOutAttend(BMMainData data) {
		if (data.isSuccess == true) {
			JOptionPane.showMessageDialog(main, "��� ����� �Ǿ����ϴ�.");
		} else {
			JOptionPane.showMessageDialog(main, "�̹� ��� ó���� �Ǿ����ϴ�.");
		}
	}

	void setSelectDayAttend(BMMainData data) {

		int row = main.bmdmP.bmdaP.BMDAmodel.getRowCount();
		if (row == -1) {
			return;
		}
		for (int i = 0; i < row; i++) {
			main.bmdmP.bmdaP.BMDAmodel.removeRow(0);
		}

		int size = data.anyList.size();

		String one = "��";

		for (int i = 0; i < size; i++) {
			BMAttendData Adata = (BMAttendData) data.anyList.get(i);
			main.bmdmP.bmdaP.BMDAmodel.addRow(new Object[6]);
			main.bmdmP.bmdaP.BMDAmodel.setValueAt(Adata, i, 0);
			main.bmdmP.bmdaP.BMDAmodel.setValueAt(Adata.attTime, i, 1);
			if (Adata.attcode.equals("1")) {
				main.bmdmP.bmdaP.BMDAmodel.setValueAt(one, i, 2);
			} else if (Adata.attcode.equals("2")) {
				main.bmdmP.bmdaP.BMDAmodel.setValueAt(one, i, 5);
			} else if (Adata.attcode.equals("3")) {
				main.bmdmP.bmdaP.BMDAmodel.setValueAt(one, i, 3);
			} else if (Adata.attcode.equals("4")) {
				main.bmdmP.bmdaP.BMDAmodel.setValueAt(one, i, 4);
			}
		}

		resizeColumnWidth(main.bmdmP.bmdaP.BMDAtable);

		main.bmdmP.bmdaP.BMDAsp.getVerticalScrollBar()
				.setValue(main.bmdmP.bmdaP.BMDAsp.getVerticalScrollBar().getMaximum());
	}

	void setSelectDesignerAttend(BMMainData data) {

		int row = main.bmdmP.bmdaP.BMDAmodel.getRowCount();
		if (row == -1) {
			return;
		}
		for (int i = 0; i < row; i++) {
			main.bmdmP.bmdaP.BMDAmodel.removeRow(0);
		}

		int size = data.anyList.size();

		String one = "��";

		for (int i = 0; i < size; i++) {
			BMAttendData Adata = (BMAttendData) data.anyList.get(i);
			main.bmdmP.bmdaP.BMDAmodel.addRow(new Object[6]);
			main.bmdmP.bmdaP.BMDAmodel.setValueAt(Adata, i, 0);
			main.bmdmP.bmdaP.BMDAmodel.setValueAt(Adata.attdate + " " + Adata.attTime, i, 1);
			if (Adata.attcode.equals("1")) {
				main.bmdmP.bmdaP.BMDAmodel.setValueAt(one, i, 2);
			} else if (Adata.attcode.equals("2")) {
				main.bmdmP.bmdaP.BMDAmodel.setValueAt(one, i, 5);
			} else if (Adata.attcode.equals("3")) {
				main.bmdmP.bmdaP.BMDAmodel.setValueAt(one, i, 3);
			} else if (Adata.attcode.equals("4")) {
				main.bmdmP.bmdaP.BMDAmodel.setValueAt(one, i, 4);
			}
		}

		resizeColumnWidth(main.bmdmP.bmdaP.BMDAtable);

		main.bmdmP.bmdaP.BMDAsp.getVerticalScrollBar()
				.setValue(main.bmdmP.bmdaP.BMDAsp.getVerticalScrollBar().getMaximum());
	}

	void textRemove() {
		main.bmdmP.bmdiP.nameF.setText("");
		main.bmdmP.bmdiP.pAddrF.setText("");
		main.bmdmP.bmdiP.birthF.setText("");
		main.bmdmP.bmdiP.genderF.setText("");
		main.bmdmP.bmdiP.addrF.setText("");
		main.bmdmP.bmdiP.DnameF.setText("");
		main.bmdmP.bmdiP.mailF.setText("");
		main.bmdmP.bmdiP.rankF.setText("");
		main.bmdmP.bmdiP.searchF.setText("");
	}

	public void resizeColumnWidth(JTable table) {
		final TableColumnModel columnModel = table.getColumnModel();
		for (int Column = 0; Column < table.getColumnCount(); Column++) {
			int width = 50;
			for (int row = 0; row < table.getRowCount(); row++) {
				TableCellRenderer renderer = table.getCellRenderer(row, Column);
				Component comp = table.prepareRenderer(renderer, row, Column);
				width = Math.max(comp.getPreferredSize().width + 1, width);
			}
			columnModel.getColumn(Column).setPreferredWidth(width);
		}
	}

	public void run() {
		try {
			while (true) {
				BMMainData data = (BMMainData) main.oin.readObject();
				if (data == null) {
					break;
				}
				switch (data.protocol) {
				case 2001: // ü���� �˻� ����
					setShopList(data);
					break;
				case 1110: // �α��� ����
					setLogin(data);
					break;
				case 1130: // ���� �˻� ����
					setSelectCustomer(data);
					break;
				case 1220: // ���� ����Ҷ� �����̳� �ҷ����� ����
					setSelectOneDesigner(data);
					break;
				case 2110: // ���� ��� ����
					setInsertCustomer(data);
					break;
				case 3110: // ���� ���� ����
					setUpdateCustomer(data);
					break;
				case 1903: // �ü� ���� �˻� ����
					setSelectMakeupInfo(data);
					break;
				case 2410: // �ü� ���
					setInsertMakeup(data);
					break;
				case 1430: // �ü� �˻� ����
					setSeletMakeup(data);
					break;
				case 2002: // ���� �˻� ����
					setRankList(data);
					break;
				case 2210: // �����̳� ��� ����
					setInsertDesigner(data);
					break;
				case 1210: // �����̳� �˻� ����
					setSelectDesigner(data);
					break;
				case 3210: // �����̳� ���� ����
					setUpdateDesigner(data);
					break;
				case 4210: // �����̳� ���� ����
					setDeleteDesigner(data);
					break;
				case 1230: // �г��� �˻� ����
					setSelectNameDesigner(data);
					break;
				case 1240: // ��ȭ��ȣ �˻� ����
					setSelectTelDesigner(data);
					break;
				case 1250: // ���� �˻� ����
					setSelectRankDesigner(data);
					break;
				case 2310: // �����̳� ��� ����
					setInsertInAttend(data);
					break;
				case 2320: // �����̳� ��� ����
					setInsertOutAttend(data);
					break;
				case 1310: // �Ϻ� ����� �˻� ����
					setSelectDayAttend(data);
					break;
				case 1320: // ���� �����̳ʺ� ����� �˻� ����
					setSelectDesignerAttend(data);
					break;
				}
			}
		} catch (Exception e) {
		} finally {
			System.exit(0);
		}
	}
}
