package Manager;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import Data.*;

//import de.javasoft.plaf.synthetica.*;

/*
 * 	�α��� ȭ���� ���� ��ȭ����
 * 	�α��� ����� ó���ϵ��� �Ѵ�.
 */
@SuppressWarnings("serial")
public class BMLoginDlg extends JDialog {

	BMMain main;
	public JComboBox<Object> cpbox;
	JTextField idF;
	JPasswordField pwF;
	JButton loginB;

	public BMLoginDlg(BMMain m) {

		main = m;

		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});

		setLayout(new BorderLayout());

		JLabel cpL = new JLabel("Company");
		JLabel idL = new JLabel("ID");
		JLabel pwL = new JLabel("Password");

		cpbox = new JComboBox<Object>();

		idF = new JTextField();
		pwF = new JPasswordField();
		loginB = new JButton("LOGIN");

		// main = new BMMain();

		loginB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// setVisible(false);
				// main.thisDisplay();
				BMShopData shop = (BMShopData) cpbox.getSelectedItem();
				String code = shop.code;
				String id = idF.getText();
				String pw = new String(pwF.getPassword());

				BMMainData data = new BMMainData();
				BMMemberData mData = new BMMemberData();
				mData.code = code;
				mData.id = id;
				mData.pw = pw;
				data.protocol = 1101;
				data.memberData = mData;
				try {
					main.oout.writeObject(data);
				} catch (Exception e1) {
				}
			}
		});

		JPanel p1 = new JPanel(new GridLayout(3, 1));
		p1.add(cpL);
		p1.add(idL);
		p1.add(pwL);

		JPanel p2 = new JPanel(new GridLayout(3, 1));
		p2.add(cpbox);
		p2.add(idF);
		p2.add(pwF);

		JPanel p3 = new JPanel(new BorderLayout());
		p3.add("West", p1);
		p3.add("Center", p2);
		p3.add("East", loginB);
		
		ImageIcon img = new ImageIcon("src/Manager/BeautyManagerImg.jpg");
		JLabel imgL = new JLabel(img);

		add("Center", imgL);
		add("South", p3);

		setTitle("BeautyManager");
		setSize(400, 500);
		setLocationRelativeTo(null);
		setVisible(true);

	}

	// public static void main(String[] args) {
	//
	// try {
	// UIManager.setLookAndFeel("ch.randelshofer.quaqua.QuaquaLookAndFeel");
	// JFrame.setDefaultLookAndFeelDecorated(true);
	// UIManager.setLookAndFeel("com.jtattoo.plaf.mcwin.McWinLookAndFeel");
	// UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
	// UIManager.setLookAndFeel("de.javasoft.plaf.synthetica.SyntheticaStandardLookAndFeel");
	// UIManager.setLookAndFeel("de.javasoft.plaf.synthetica.SyntheticaBlackStarLookAndFeel");
	// SyntheticaLookAndFeel.setFont("Dialog", 12);
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// new BMLoginDlg();

	// }

}
