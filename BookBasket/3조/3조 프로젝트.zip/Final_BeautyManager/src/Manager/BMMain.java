package Manager;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

import javax.swing.*;

import Customer.*;
import Data.*;
import Designer.*;
import Receive.*;

/*
 * 	��Ʈ��ũ ����
 * 	�������� ����ȭ��
 * 	�����̳ʰ��� ����ȭ���� �����Ѵ�.
 * 	==>	���� �� ȭ���� CardLayout ������� �����ϵ��� �Ѵ�.
 */
@SuppressWarnings("serial")
public class BMMain extends JFrame {

	public Socket socket;
	public ObjectInputStream oin;
	public ObjectOutputStream oout;

	JPanel mainP;
	CardLayout card;
	public BMCustormerMain bmcmP;
	public BMDesignerMain bmdmP;

	JButton custormerB, designerB;

	public BMLoginDlg loginDlg;
	public BMReceiveThread thread;

	public BMMain() {

		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});

		mainP = new JPanel();
		card = new CardLayout();
		mainP.setLayout(card);

		bmcmP = new BMCustormerMain(this);
		bmdmP = new BMDesignerMain(this);

		mainP.add(bmcmP, "CUSTORMER");
		mainP.add(bmdmP, "DESIGNER");

		custormerB = new JButton("���� ����");
		designerB = new JButton("�����̳� ����");

		ButtonEvent evt = new ButtonEvent();
		custormerB.addActionListener(evt);
		designerB.addActionListener(evt);

		JPanel p1 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		p1.add(custormerB);
		p1.add(designerB);

		add("Center", mainP);
		add("South", p1);

		ImageIcon icon = new ImageIcon("src/Manager/TitleIcon.png");
		setIconImage(icon.getImage());

		setTitle("BeautyManager");
		setSize(1000, 600);
		setLocationRelativeTo(null);
		// setVisible(true);
		loginDlg = new BMLoginDlg(this);
		try {
			socket = new Socket("192.168.35.63", 7777);
			oout = new ObjectOutputStream(socket.getOutputStream());
			oin = new ObjectInputStream(socket.getInputStream());

			thread = new BMReceiveThread(this);
			thread.start();

			BMMainData data = new BMMainData();
			data.protocol = 1901;
			oout.writeObject(data);
		} catch (Exception e) {
			System.out.println("������� ���� = " + e);
			System.exit(0);
		}
	}

	public void thisDisplay() {
		loginDlg.setVisible(false);
		// �α��δ�ȭ���� ������� �ϰ�
		setResizable(false);
		setVisible(true);
		BMMainData sData = new BMMainData();
		BMCustomerData cData = new BMCustomerData();
		sData.protocol = 1103;
		cData.kind = "��ü";
		sData.customerData = cData;
		try {
			oout.writeObject(sData);
		} catch (Exception e) {
			System.out.println("���� ��� �ҷ����� ���� = " + e);
		}
	}

	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel("com.jtattoo.plaf.mcwin.McWinLookAndFeel");
		} catch (Exception e) {
			e.printStackTrace();
		}
		new BMMain();
	}

	void designerinfoProc() {

		BMMainData data = new BMMainData();
		BMDesignerData dData = new BMDesignerData();

		data.protocol = 1201;
		data.designerData = dData;
		try {
			oout.writeObject(data);
		} catch (Exception e) {
		}
	}

	class ButtonEvent implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == custormerB) {
				bmcmP.bmciP.nameF.setText("");
				bmcmP.bmciP.pAddrF.setText("");
				bmcmP.bmciP.Dbox.setSelectedItem("");
				bmcmP.bmciP.genderF.setText("");
				bmcmP.bmciP.mailF.setText("");
				bmcmP.bmciP.searchF.setText("");

				card.show(mainP, "CUSTORMER");
			} else {
				designerinfoProc();
				bmdmP.bmdaP.calendar.selectDayAttendProc();

				bmdmP.bmdiP.nameF.setText("");
				bmdmP.bmdiP.pAddrF.setText("");
				bmdmP.bmdiP.birthF.setText("");
				bmdmP.bmdiP.genderF.setText("");
				bmdmP.bmdiP.addrF.setText("");
				bmdmP.bmdiP.DnameF.setText("");
				bmdmP.bmdiP.mailF.setText("");
				bmdmP.bmdiP.rankF.setText("");
				bmdmP.bmdiP.searchF.setText("");

				card.show(mainP, "DESIGNER");
			}
		}

	}

}
