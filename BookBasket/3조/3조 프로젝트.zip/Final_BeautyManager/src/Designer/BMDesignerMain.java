package Designer;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import Data.*;
import Manager.*;

/*
 * 	�����̳� ����
 * 	���� ����
 * 	���� �ΰ����� ������ �̿��ؼ� �����ϴ� ���
 */
@SuppressWarnings("serial")
public class BMDesignerMain /* extends JPanel */ extends JPanel {

	public BMMain main;

	JButton insertB;
	public BMDesignerInfo bmdiP;
	public BMDesignerAttend bmdaP;
	public BMDesignerJoin bmdjD;
	
	JTabbedPane tab;

	public BMDesignerMain(BMMain m) {

		main = m;

		insertB = new JButton("�����̳� ���");
		insertB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				bmdjD = new BMDesignerJoin(BMDesignerMain.this);

				BMMainData data = new BMMainData();
				data.protocol = 1902;
				try {
					main.oout.writeObject(data);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});

		JPanel p1 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		p1.add(insertB);

		bmdiP = new BMDesignerInfo(BMDesignerMain.this);
		bmdaP = new BMDesignerAttend(BMDesignerMain.this);

		tab = new JTabbedPane();

		tab.addTab("�����̳� ����", bmdiP);
		tab.addTab("�����̳� ��������", bmdaP);
		tab.addChangeListener(new TabEvent());

		setLayout(new BorderLayout());
		add("North", p1);
		add("Center", tab);

		// setTitle("BeautyManager");
		// setSize(720, 600);
		// setVisible(true);

	}
	
	class TabEvent implements ChangeListener {

		@Override
		public void stateChanged(ChangeEvent e) {
			if (tab.getSelectedIndex() == 1) {
				
				bmdaP.calendar.selectDayAttendProc();

//				BMMainData data = new BMMainData();
//				BMAttendData dData = new BMAttendData();
//
//				data.protocol = 1301;
//				data.attendData = dData;
//				try {
//					main.oout.writeObject(data);
//				} catch (Exception e1) {
//				}
			}
		}

	}

}
