package Designer;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

import Data.*;

import java.awt.*;
import java.awt.event.*;

/*
 * 	�����̳� ���� ������ ���� ȭ�� ����
 * �����̸�, �޴��ȣ, �������, ����, �ּ�, �Ի���, �̸���, �޸�, ����
 */
@SuppressWarnings("serial")
public class BMDesignerInfo /* extends JPanel */ extends JPanel {

	BMDesignerMain dMain;

	JButton searchB, infoModifyB, deleteB, gOfficeB, lOfficeB;
	public JTextField nameF, pAddrF, birthF, genderF, addrF, DnameF, mailF, rankF, searchF;
	public JTable table;
	JComboBox<String> Cbox;
	JLabel nameL, pAddrL, birthL, genderL, addrL, DnameL, mailL, rankL;
	public DefaultTableModel model;
	Image img = null;
	int no;
	public JScrollPane sp;

	public BMDesignerInfo(BMDesignerMain m) {

		dMain = m;

		searchB = new JButton("�˻�");
		infoModifyB = new JButton("��������");
		deleteB = new JButton("����");
		gOfficeB = new JButton("���");
		lOfficeB = new JButton("���");

		ButttonEvent evt = new ButttonEvent();
		searchB.addActionListener(evt);
		infoModifyB.addActionListener(evt);
		deleteB.addActionListener(evt);
		gOfficeB.addActionListener(evt);
		lOfficeB.addActionListener(evt);

		nameL = new JLabel("�̸�");
		pAddrL = new JLabel("��ȭ��ȣ");
		birthL = new JLabel("�������");
		genderL = new JLabel("����");
		addrL = new JLabel("�ּ�");
		DnameL = new JLabel("�г���");
		mailL = new JLabel("�̸���");
		rankL = new JLabel("����");

		nameF = new JTextField(10);
		pAddrF = new JTextField(10);
		birthF = new JTextField(10);
		genderF = new JTextField(10);
		addrF = new JTextField(10);
		DnameF = new JTextField(10);
		mailF = new JTextField(10);
		rankF = new JTextField(10);
		searchF = new JTextField(10);

		String[] title = { "��ȣ", "�̸�", "��ȭ��ȣ", "�������", "����", "�ּ�", "�Ի���", "�̸����ּ�", "�г���", "����" };
		model = new DefaultTableModel(title, 0) {
			public boolean isCellEditable(int i, int c) {
				return false;
			}
		};

		table = new JTable(model);

		DefaultTableCellRenderer tScheduleCellRenderer = new DefaultTableCellRenderer();
		tScheduleCellRenderer.setHorizontalAlignment(SwingConstants.CENTER);
		TableColumnModel tcmSchedule = table.getColumnModel();
		for (int i = 0; i < tcmSchedule.getColumnCount(); i++) {
			tcmSchedule.getColumn(i).setCellRenderer(tScheduleCellRenderer);
		}

		// table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.getTableHeader().setReorderingAllowed(false);
		table.getTableHeader().setResizingAllowed(false);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		table.addMouseListener(new TableEvent());
		sp = new JScrollPane(table);

		String[] items = { "��ü", "�г���", "��ȭ��ȣ", "����" };
		Cbox = new JComboBox<String>(items);
		Cbox.addActionListener(new ComboEvent());
		searchF.setEnabled(false);

		TitledBorder tborder = new TitledBorder("���� ����");
		TitledBorder cborder = new TitledBorder("���� ����");
		TitledBorder mborder = new TitledBorder("�˻� ���");

		JPanel p1 = new JPanel(new GridLayout(8, 1));
		p1.add(nameL);
		p1.add(pAddrL);
		p1.add(birthL);
		p1.add(genderL);
		p1.add(addrL);
		p1.add(mailL);
		p1.add(DnameL);
		p1.add(rankL);

		JPanel p2 = new JPanel(new GridLayout(8, 1));
		p2.add(nameF);
		p2.add(pAddrF);
		p2.add(birthF);
		p2.add(genderF);
		p2.add(addrF);
		p2.add(mailF);
		p2.add(DnameF);
		p2.add(rankF);

		JPanel p31 = new JPanel(new GridLayout(1, 2));
		p31.add(infoModifyB);
		p31.add(deleteB);

		JPanel p3 = new JPanel(new BorderLayout());
		p3.add("West", p1);
		p3.add("East", p2);
		p3.add("South", p31);
		p3.setBorder(cborder);

		JPanel p4 = new JPanel(new GridLayout(1, 2));
		p4.add(Cbox);
		p4.add(searchF);

		JPanel p5 = new JPanel(new BorderLayout());
		p5.add("North", p4);
		p5.add("South", searchB);

		JPanel p6 = new JPanel(new GridLayout(1, 2));
		p6.add(gOfficeB);
		p6.add(lOfficeB);

		JPanel p7 = new JPanel(new BorderLayout());
		p7.add("North", p5);
		p7.add("South", p6);
		p7.setBorder(mborder);

		JPanel p8 = new JPanel(new BorderLayout());
		p8.add("North", p3);
		p8.add("South", p7);

		JPanel p9 = new JPanel(new BorderLayout());
		p9.add(sp);
		p9.setBorder(tborder);

		setLayout(new BorderLayout());
		add("East", p8);
		add("Center", p9);

		// this.setSize(700, 500);
		// this.setVisible(true);
	}

	class TableEvent extends MouseAdapter {
		@Override
		public void mousePressed(MouseEvent e) {
			int row = table.getSelectedRow();

			if (row == -1) {
				return;
			}

			BMDesignerData Ddata = (BMDesignerData) table.getValueAt(row, 1);
			no = Ddata.no;
			nameF.setText(Ddata.name);
			pAddrF.setText(Ddata.tel);
			birthF.setText(Ddata.birth);
			genderF.setText(Ddata.gender);
			addrF.setText(Ddata.address);
			mailF.setText(Ddata.email);
			DnameF.setText(Ddata.nick);
			rankF.setText(Ddata.rank);
		}
	}

	void searchProc() {

		String item = (String) Cbox.getSelectedItem();
		String sf = searchF.getText();

		if (sf.equals("") && item != "��ü") {
			JOptionPane.showMessageDialog(dMain, "�˻��� ������ �Է��ϼ���.");
			return;
		}

		BMMainData data = new BMMainData();
		BMDesignerData dData = new BMDesignerData();

		if (item == "����") {
			dData.rank = sf;
			data.protocol = 1205;
		} else if (item == "�г���") {
			dData.nick = sf;
			data.protocol = 1203;
		} else if (item == "��ȭ��ȣ") {
			dData.tel = sf;
			data.protocol = 1204;
		} else {
			data.protocol = 1201;
		}

		data.designerData = dData;

		try {
			dMain.main.oout.writeObject(data);
		} catch (Exception e) {
		}

	}

	void modifyProc() {

		String name = nameF.getText();
		String tel = pAddrF.getText();
		String birth = birthF.getText();
		String gen = genderF.getText();
		String addr = addrF.getText();
		String email = mailF.getText();
		String Dname = DnameF.getText();
		String rank = rankF.getText();

		BMMainData data = new BMMainData();
		BMDesignerData dData = new BMDesignerData();

		dData.no = no;

		dData.name = name;
		dData.gender = gen;
		dData.birth = birth;
		dData.tel = tel;
		dData.address = addr;
		dData.email = email;
		dData.nick = Dname;
		dData.rank = rank;

		data.protocol = 3201;
		data.designerData = dData;
		try {
			dMain.main.oout.writeObject(data);
		} catch (Exception e) {
		}

	}

	void deleteProc() {

		BMMainData data = new BMMainData();
		BMDesignerData dData = new BMDesignerData();

		dData.no = no;

		data.protocol = 4201;
		data.designerData = dData;
		try {
			dMain.main.oout.writeObject(data);
		} catch (Exception e) {
		}

	}

	void inProc() {

		BMMainData data = new BMMainData();
		BMDesignerData dData = new BMDesignerData();

		if (no == 0) {
			JOptionPane.showMessageDialog(dMain, "��� ó�� �� �����̳ʸ� �����ϼ���");
			return;
		}

		dData.no = no;

		data.protocol = 2301;
		data.designerData = dData;

		try {
			dMain.main.oout.writeObject(data);
		} catch (Exception e) {
		}

	}

	void outProc() {

		BMMainData data = new BMMainData();
		BMDesignerData dData = new BMDesignerData();

		if (no == 0) {
			JOptionPane.showMessageDialog(dMain, "��� ó�� �� �����̳ʸ� �����ϼ���");
			return;
		}

		dData.no = no;

		data.protocol = 2302;
		data.designerData = dData;

		try {
			dMain.main.oout.writeObject(data);
		} catch (Exception e) {
		}

	}

	class ButttonEvent implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == searchB) {
				searchProc();
			} else if (e.getSource() == infoModifyB) {
				modifyProc();
			} else if (e.getSource() == deleteB) {
				deleteProc();
			} else if (e.getSource() == gOfficeB) {
				inProc();
			} else {
				outProc();
			}
		}

	}

	class ComboEvent implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {

			String item = (String) Cbox.getSelectedItem();
			if (item == "��ü") {
				searchF.setText("");
				searchF.setEnabled(false);
			} else {
				searchF.setEnabled(true);
			}

		}

	}

}
