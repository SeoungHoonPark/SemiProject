package Designer;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.*;

import Data.*;

/*
 * 	�����̳� ���� ��� ��ȭ����
 */
@SuppressWarnings("serial")
public class BMDesignerJoin /* extends JDialog */ extends JDialog {

	BMDesignerMain dMain;

	JTextField nameF, aNameF, hireDateF, pAddrF1, pAddrF2, addrF, mailF, birthF;
	JLabel nameL, aNameL, genderL, birthL, rankL, hireDateL, emailL, pAddrL, addrL, ehireDateL, epAddrL, label1,
			binlabel1, binlabel2;
	JTextArea area;

	public JComboBox<Object> rankC;

	public JComboBox<String> mailC, phoneC;
	ButtonGroup bg;
	JRadioButton male, female;
	TitledBorder infoBorder, bBorder;
	JScrollPane sp;
	JButton transB, cancelB;

	public BMDesignerJoin(BMDesignerMain m) {

		dMain = m;

		infoBorder = new TitledBorder("�⺻����");
		bBorder = new TitledBorder("���");

		// ��
		nameL = new JLabel("�����̸�");
		aNameL = new JLabel("�����̳ʸ�");
		genderL = new JLabel("����");
		rankL = new JLabel("��å");
		// hireDateL = new JLabel("�Ի���");
		pAddrL = new JLabel("�޴���");
		addrL = new JLabel("�ּ�");
		ehireDateL = new JLabel("ex)20170213");
		epAddrL = new JLabel("*�ʼ��Է�*");
		epAddrL.setForeground(Color.red);
		emailL = new JLabel("�̸���");
		birthL = new JLabel("�������");
		label1 = new JLabel("@");
		binlabel1 = new JLabel();
		binlabel2 = new JLabel();

		// �ؽ�Ʈ�ʵ�
		nameF = new JTextField(10);
		aNameF = new JTextField(10);
		// hireDateF = new JTextField(10);
		pAddrF1 = new JTextField(4);
		pAddrF2 = new JTextField(4);
		addrF = new JTextField(47);
		mailF = new JTextField(10);
		birthF = new JTextField(10);

		// �޺��ڽ�
		String phone[] = { "010", "011", "070" };
		// String level[] = { "����", "�ο���", "����", "�Ŵ���", "�����̳�", "����" };
		String items[] = { "naver.com", "nate.com", "daum.net", "gmail.com" };
		phoneC = new JComboBox<String>(phone);
		mailC = new JComboBox<String>(items);
		rankC = new JComboBox<Object>();
		rankC.setPreferredSize(new Dimension(96, 30));

		// ���
		area = new JTextArea();
		sp = new JScrollPane(area);

		// ������ư
		bg = new ButtonGroup();
		male = new JRadioButton("�� ��");
		female = new JRadioButton("�� ��");
		bg.add(male);
		bg.add(female);

		// ��ư
		transB = new JButton("�� ��");
		cancelB = new JButton("�� ��");

		ButtonEvent evt = new ButtonEvent();
		transB.addActionListener(evt);
		cancelB.addActionListener(evt);

		// ���ʶ� ����
		JPanel p1 = new JPanel(new GridLayout(4, 1, 5, 5));
		p1.add(nameL);
		p1.add(genderL);
		p1.add(birthL);
		// p1.add(hireDateL);
		p1.add(pAddrL);

		// �����ʵ� ����
		JPanel p21 = new JPanel(new GridLayout(1, 3, 2, 2));
		p21.add(phoneC);
		p21.add(pAddrF1);
		p21.add(pAddrF2);

		JPanel p22 = new JPanel(new GridLayout(1, 2, 2, 2));
		p22.add(male);
		p22.add(female);

		JPanel p2 = new JPanel(new GridLayout(4, 1, 5, 5));
		p2.add(nameF);
		p2.add(p22);
		p2.add(birthF);
		// p2.add(hireDateF);
		p2.add(p21);
		p2.setPreferredSize(new Dimension(180, 100));

		// �����ʶ� ����
		JPanel p3 = new JPanel(new GridLayout(4, 1, 5, 5));
		p3.add(aNameL);
		p3.add(rankL);
		p3.add(emailL);
		// p3.add(ehireDateL);
		p3.add(epAddrL);

		// ���Ϲ���
		JPanel p31 = new JPanel(new BorderLayout());
		p31.add("Center", mailF);
		p31.add("East", label1);

		// �������ʵ� ����
		JPanel p41 = new JPanel(new GridLayout(1, 2, 2, 2));
		p41.add(p31);
		p41.add(mailC);
		JPanel p4 = new JPanel(new GridLayout(4, 1, 5, 5));
		p4.add(aNameF);
		p4.add(rankC);
		p4.add(p41);
		p4.add(binlabel1);
		// p4.add(binlabel2);
		p4.setPreferredSize(new Dimension(180, 100));

		// ���� ����
		// JPanel p5 = new JPanel(new GridLayout(1, 2, 10, 10));
		JPanel p5 = new JPanel(new BorderLayout());
		p5.add("West", p1);
		p5.add("East", p2);
		// p5.add(p1);
		// p5.add(p2);

		// ������ ����
		// JPanel p6 = new JPanel(new GridLayout(1, 2, 10, 10));
		JPanel p6 = new JPanel(new BorderLayout());
		p6.add("West", p3);
		p6.add("East", p4);
		// p6.add(p3);
		// p6.add(p4);

		// �⺻���� ����
		JPanel p7 = new JPanel(new GridLayout(1, 2, 25, 0));
		// JPanel p7 = new JPanel(new BorderLayout());
		// p7.add("West", p5);
		// p7.add("East", p6);
		p7.add(p5);
		p7.add(p6);

		// �ּ�
		JPanel p8 = new JPanel(new BorderLayout());
		p8.add("West", addrL);
		p8.add("East", addrF);

		// ���, �����ҹ�ư ����
		JPanel p91 = new JPanel();
		p91.add(transB);
		p91.add(cancelB);
		JPanel p9 = new JPanel(new BorderLayout());
		p9.add("Center", sp);
		p9.add("South", p91);
		p9.setBorder(bBorder);

		// �⺻����, �ּ� ����
		JPanel p10 = new JPanel(new BorderLayout());
		p10.add("Center", p7);
		p10.add("South", p8);
		p10.setBorder(infoBorder);

		setLayout(new BorderLayout());
		add("North", p10);
		add("Center", p9);

		setTitle("Beauty Manager �����̳� ���");
		setSize(667, 400);
		setLocationRelativeTo(null);
		setResizable(false);
		setVisible(true);

	}

	void insertProc() {

		String name = nameF.getText();
		String gen = "";
		if (male.isSelected()) {
			gen = "M";
		} else {
			gen = "F";
		}
		String birth = birthF.getText();
		String tel = phoneC.getSelectedItem().toString() + "-" + pAddrF1.getText() + "-" + pAddrF2.getText();
		String addr = addrF.getText();
		String email = mailF.getText() + "@" + mailC.getSelectedItem().toString();
		String Dname = aNameF.getText();
		String rank = rankC.getSelectedItem().toString();

		BMMainData data = new BMMainData();
		BMDesignerData dData = new BMDesignerData();

		dData.name = name;
		dData.gender = gen;
		dData.birth = birth;
		dData.tel = tel;
		dData.address = addr;
		dData.email = email;
		dData.nick = Dname;
		dData.rank = rank;

		data.protocol = 2201;
		data.designerData = dData;
		try {
			dMain.main.oout.writeObject(data);
		} catch (Exception e) {
		}

	}

	class ButtonEvent implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == transB) {
				insertProc();
			} else {
				setVisible(false);
			}
		}

	}

}
