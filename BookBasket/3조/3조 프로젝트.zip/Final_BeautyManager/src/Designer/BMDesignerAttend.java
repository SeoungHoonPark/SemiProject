package Designer;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

import Calendar.*;
import Data.*;

/*
 * 	�����̳� ���� ���� ȭ��
 */

@SuppressWarnings("serial")
public class BMDesignerAttend /* extends JPanel */ extends JPanel {

	public BMDesignerMain dMain;

	public JTable BMDAtable;
	public DefaultTableModel BMDAmodel;
	public JScrollPane BMDAsp;
	JTextField BMDAField;
	JButton BMDAbtn;
	public CalendarFrame calendar;
	JLabel BMDAlabel;

	public BMDesignerAttend(BMDesignerMain m) {

		dMain = m;

		calendar = new CalendarFrame(BMDesignerAttend.this);

		String[] title = { "�г���", "����ٽð�", "�������", "����", "����", "�������" };
		BMDAmodel = new DefaultTableModel(title, 0) {
			public boolean isCellEditable(int i, int c) {
				return false;
			}
		};
		BMDAtable = new JTable(BMDAmodel);
		BMDAsp = new JScrollPane(BMDAtable);

		DefaultTableCellRenderer tScheduleCellRenderer = new DefaultTableCellRenderer();
		tScheduleCellRenderer.setHorizontalAlignment(SwingConstants.CENTER);
		TableColumnModel tcmSchedule = BMDAtable.getColumnModel();
		for (int i = 0; i < tcmSchedule.getColumnCount(); i++) {
			tcmSchedule.getColumn(i).setCellRenderer(tScheduleCellRenderer);
		}

		BMDAtable.getTableHeader().setReorderingAllowed(false);
		BMDAtable.getTableHeader().setResizingAllowed(false);

		BMDAField = new JTextField();
		BMDAlabel = new JLabel("�г���");

		BMDAbtn = new JButton("�˻�");
		BMDAbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String nick = BMDAField.getText();

				if (nick.equals("")) {
					JOptionPane.showMessageDialog(dMain, "�г����� �Է��ϼ���.");
					return;
				}

				String cal = calendar.selectDesignerAttend();

				BMMainData data = new BMMainData();
				BMAttendData aData = new BMAttendData();

				aData.date = cal;
				aData.nick = nick;
				data.protocol = 1302;
				data.attendData = aData;

				try {
					dMain.main.oout.writeObject(data);
				} catch (Exception e1) {
				}
			}
		});

		JPanel p4 = new JPanel(new BorderLayout(10, 10));
		p4.add("West", BMDAlabel);
		p4.add("Center", BMDAField);

		JPanel p1 = new JPanel(new GridLayout(1, 2, 10, 10));
		// p1.add(BMDAlabel);
		// p1.add(BMDAField);
		p1.add(p4);
		p1.add(BMDAbtn);

		TitledBorder Tborder = new TitledBorder("���� ����");

		JPanel p2 = new JPanel(new BorderLayout());
		p2.add("Center", BMDAsp);
		p2.add("South", p1);

		JPanel p3 = new JPanel(new BorderLayout());
		p3.add(p2);
		p3.setBorder(Tborder);

		setLayout(new BorderLayout());
		add("Center", calendar.contentPane);
		add("East", p3);

		// setTitle("BeautyManager");
		// setSize(1030, 550);
		// setVisible(true);

	}

}
