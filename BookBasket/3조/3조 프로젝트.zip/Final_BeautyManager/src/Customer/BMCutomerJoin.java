package Customer;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.*;

import Data.*;

/*
 * 	���� ���� ��� ��ȭ����
 */
@SuppressWarnings("serial")
public class BMCutomerJoin /* extends JDialog */ extends JDialog {

	BMCustormerMain cMain;

	JTextField nameF, emailF, telF1, telF2;
	ButtonGroup bg;
	JRadioButton male, female;
	JComboBox<String> telCB; // �ڵ��� ComboBox
	public JComboBox<Object> designerCB; // �����̳� �̸� ComboBox ����
	JComboBox<String> emailCB;
	JTextArea area;
	JScrollPane sp;
	JButton insertB, cancelB; // Button ����

	public BMCutomerJoin(BMCustormerMain m) {

		cMain = m;

		JLabel label[] = new JLabel[11];
		nameF = new JTextField(8);
		emailF = new JTextField(8);
		telF1 = new JTextField(4);
		telF2 = new JTextField(4);
		JScrollPane sp;

		String phone[] = { "010", "011", "070" }; // ComboBox ����

		// JComboBox<String> designerCB; // ���̳� �̸� ComboBox ����
		// String Dname[] = { "", "����", "������", "���±�", "�ڹ�", "������", "���ϸ�" };

		JPanel panel1, panel3, panel4, panel5, panel6, panel7, panel8;
		JPanel panel11, panel12, panel41;

		label[0] = new JLabel("�̸���");
		label[1] = new JLabel("�̸�");
		label[2] = new JLabel("�������̳�");
		label[3] = new JLabel("����");
		label[4] = new JLabel("�޴���");
		label[5] = new JLabel("*ȫ�� �� ��������*");
		label[6] = new JLabel("*�ʼ��Է�*");
		label[6].setForeground(Color.RED);
		label[7] = new JLabel("-");
		label[8] = new JLabel("@");
		label[9] = new JLabel("���");

		nameF = new JTextField(8);
		emailF = new JTextField(8);
		telF1 = new JTextField(4);
		telF2 = new JTextField(4);
		area = new JTextArea(1, 1);
		sp = new JScrollPane(area);

		male = new JRadioButton("�� ��");
		female = new JRadioButton("�� ��");

		bg = new ButtonGroup();
		bg.add(male);
		bg.add(female);

		telCB = new JComboBox<String>(phone);
		designerCB = new JComboBox<Object>();

		panel1 = new JPanel(new GridLayout(1, 2));
		panel1.add(label[1]);
		panel1.add(nameF);

		panel11 = new JPanel(new GridLayout(1, 2));
		panel11.add(label[2]);
		panel11.add(designerCB);

		// 1��
		panel12 = new JPanel(new GridLayout(1, 2, 50, 0));
		panel12.add(panel1);
		panel12.add(panel11);

		String email[] = { "naver.com", "hanmail.net", "gmail.com" };
		emailCB = new JComboBox<String>(email);

		JPanel p4 = new JPanel(new BorderLayout());
		p4.add("West", label[0]);
		p4.add("Center", emailF);
		p4.add("East", label[8]);

		JPanel p5 = new JPanel(new GridLayout(1, 2));
		p5.add(p4);
		p5.add(emailCB);

		// 2��
		panel3 = new JPanel(new GridLayout(1, 2, 50, 0));
		panel3.add(p5);
		panel3.add(label[5]);

		JPanel p2 = new JPanel();
		p2.add(male);
		p2.add(female);

		JPanel P01 = new JPanel(new GridLayout(1, 2));
		P01.add(label[3]);
		P01.add(p2);

		JLabel lb = new JLabel("");
		JPanel P02 = new JPanel(new GridLayout(1, 2, 50, 0));
		P02.add(P01);
		P02.add(lb);

		panel4 = new JPanel(new GridLayout(1, 4, 10, 0));
		panel4.add(label[4]);
		panel4.add(telCB);
		panel4.add(telF1);
		panel4.add(telF2);

		// 4��
		panel41 = new JPanel(new GridLayout(1, 2, 50, 0));
		panel41.add(panel4);
		panel41.add(label[6]);

		// ����
		panel5 = new JPanel(new GridLayout(4, 1, 10, 10));
		panel5.add(panel12);
		panel5.add(P02);
		panel5.add(panel3);
		panel5.add(panel41);
		panel5.setPreferredSize(new Dimension(450, 160));

		TitledBorder Tborder = new TitledBorder("�⺻����");
		panel5.setBorder(Tborder);

		// ���
		panel6 = new JPanel(new BorderLayout());
		panel6.add("Center", sp);

		// �Ʒ�
		insertB = new JButton(" ��    �� ");
		cancelB = new JButton(" ��    ��");

		ButtonEvent evt = new ButtonEvent();
		insertB.addActionListener(evt);
		cancelB.addActionListener(evt);

		panel7 = new JPanel();
		panel7.add(insertB);
		panel7.add(cancelB);

		// ���/�Ʒ�
		panel8 = new JPanel(new BorderLayout());
		panel8.add(panel6, "Center");
		panel8.add(panel7, "South");
		TitledBorder Tborder1 = new TitledBorder("���");
		panel8.setBorder(Tborder1);

		this.setLayout(new BorderLayout());

		this.add("North", panel5);
		this.add(panel8);

		setTitle("Beauty Manager �������");
		setResizable(false);
		setSize(600, 400);
		setLocationRelativeTo(null);
		setVisible(true);
	}

	void insertProc() {

		String name = nameF.getText();
		String designer = designerCB.getSelectedItem().toString();
		String gender = "";
		if (male.isSelected()) {
			gender = "M";
		} else {
			gender = "F";
		}
		String email = emailF.getText() + "@" + emailCB.getSelectedItem().toString();
		String tel = telCB.getSelectedItem().toString() + "-" + telF1.getText() + "-" + telF2.getText();
		String bigo = area.getText();

		BMMainData mainD = new BMMainData();
		BMCustomerData cData = new BMCustomerData();

		mainD.protocol = 2101;
		cData.kind = "��ü";
		cData.name = name;
		cData.desingerName = designer;
		cData.gender = gender;
		cData.email = email;
		cData.tel = tel;
		cData.bigo = bigo;

		mainD.customerData = cData;

		try {
			cMain.main.oout.writeObject(mainD);
		} catch (Exception e) {
			System.out.println("���� ��� ���� = " + e);
		}
	}

	class ButtonEvent implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == insertB) {
				insertProc();
			} else {
				setVisible(false);
			}
		}

	}

}
