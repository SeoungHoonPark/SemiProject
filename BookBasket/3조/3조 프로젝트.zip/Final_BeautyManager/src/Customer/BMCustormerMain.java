package Customer;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import Data.*;
import Manager.*;

/*
 * 		�������� ���� ȭ������
 * 		�������� ȭ��� �ü����� ȭ���� ���� �����ϱ� ���� Ŭ����
 */
@SuppressWarnings("serial")
public class BMCustormerMain /* extends JPanel */ extends JPanel {

	public BMMain main;

	JButton insertB;
	public BMCustomerInfo bmciP;
	public BMCustomerDesign bmcdP;
	public BMCutomerJoin bmcjD;

	JTabbedPane tab;

	public BMCustormerMain(BMMain m) {

		main = m;

		insertB = new JButton("���� ���");
		insertB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				bmcjD = new BMCutomerJoin(BMCustormerMain.this);
				BMMainData data = new BMMainData();
				data.protocol = 1202;
				try {
					main.oout.writeObject(data);
				} catch (Exception e1) {
					System.out.println("���� = " + e);
				}
			}
		});

		JPanel p1 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		p1.add(insertB);

		bmciP = new BMCustomerInfo(this);
		bmcdP = new BMCustomerDesign(this);

		tab = new JTabbedPane();
		tab.addTab("���� ����", bmciP);
		tab.addTab("�ü� ����", bmcdP);
		tab.addChangeListener(new TabEvent());

		setLayout(new BorderLayout());
		add("North", p1);
		add("Center", tab);

		// setSize(720, 600);
		// setVisible(true);
	}

	class TabEvent implements ChangeListener {

		@Override
		public void stateChanged(ChangeEvent e) {
			if (tab.getSelectedIndex() == 1) {
				BMMainData data = new BMMainData();
				BMDesignData dData = new BMDesignData();

				data.protocol = 1403;
				dData.kind = "��ü";
				data.designData = dData;

				try {
					main.oout.writeObject(data);
				} catch (Exception e1) {
				}
			}
		}

	}

}
