package Customer;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

import Data.*;

/*
 * 	�ü����� ������ Ȯ���ϱ� ���� Ŭ����
 */
@SuppressWarnings("serial")
public class BMCustomerDesign /* extends JPanel */ extends JPanel {

	BMCustormerMain cMain;

	public JTable BMCDtable;
	public DefaultTableModel BMCDmodel;
	public JScrollPane BMCDtsp, BMCDasp;
	JTextArea BMCDarea;
	JComboBox<String> BMCDbox;
	JTextField BMCDField;
	JButton BMCDbtn;

	public BMCustomerDesign(BMCustormerMain m) {

		cMain = m;

		String[] title = { "��ȣ", "�ü���¥", "�̸�", "�ü���", "�����", "�ü��ݾ�" };
		BMCDmodel = new DefaultTableModel(title, 0) {
			public boolean isCellEditable(int i, int c) {
				return false;
			}
		};
		BMCDtable = new JTable(BMCDmodel);

		DefaultTableCellRenderer tScheduleCellRenderer = new DefaultTableCellRenderer();
		tScheduleCellRenderer.setHorizontalAlignment(SwingConstants.CENTER);
		TableColumnModel tcmSchedule = BMCDtable.getColumnModel();
		for (int i = 0; i < tcmSchedule.getColumnCount(); i++) {
			tcmSchedule.getColumn(i).setCellRenderer(tScheduleCellRenderer);
		}

		BMCDtable.getTableHeader().setReorderingAllowed(false);
		BMCDtable.getTableHeader().setResizingAllowed(false);
		BMCDtable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		BMCDtable.addMouseListener(new TableEvent());
		BMCDtsp = new JScrollPane(BMCDtable);

		BMCDarea = new JTextArea(15, 15);
		BMCDarea.setEditable(false);
		BMCDasp = new JScrollPane(BMCDarea);

		BMCDbox = new JComboBox<String>();
		BMCDbox.addItem("��ü");
		BMCDbox.addItem("������");
		BMCDbox.addItem("����ڸ�");

		BMCDField = new JTextField();

		BMCDbox.addActionListener(new ComboEvent());
		BMCDField.setEnabled(false);

		BMCDbtn = new JButton("�˻�");
		BMCDbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				BMCDarea.setText("");
				String item = (String) BMCDbox.getSelectedItem();
				String sf = BMCDField.getText();

				if (sf.equals("") && item != "��ü") {
					JOptionPane.showMessageDialog(cMain, "�˻��� ������ �Է��ϼ���.");
					return;
				}

				BMMainData data = new BMMainData();
				BMDesignData dData = new BMDesignData();

				data.protocol = 1403;
				dData.kind = item;
				dData.searchText = sf;
				data.designData = dData;

				try {
					cMain.main.oout.writeObject(data);
				} catch (Exception e1) {
				}
			}
		});

		TitledBorder Bborder = new TitledBorder("�˻�");
		JPanel p1 = new JPanel(new GridLayout(1, 2, 2, 2));
		p1.add(BMCDbox);
		p1.add(BMCDField);

		JPanel p5 = new JPanel(new BorderLayout());
		p5.add("North", p1);
		p5.add("South", BMCDbtn);
		p5.setBorder(Bborder);

		TitledBorder Tborder = new TitledBorder("�ü� ����");

		JPanel p2 = new JPanel(new BorderLayout());
		p2.add(BMCDtsp);
		p2.setBorder(Tborder);

		TitledBorder Aborder = new TitledBorder("�޸�");

		JPanel p3 = new JPanel(new BorderLayout());
		p3.add(BMCDasp);
		p3.setBorder(Aborder);

		JPanel p4 = new JPanel(new BorderLayout());

		p4.setPreferredSize(new Dimension(200, 300));

		p4.add("North", p3);
		p4.add("South", p5);

		setLayout(new BorderLayout());

		add("Center", p2);
		add("East", p4);

		// setSize(810, 565);
		// setVisible(true);
	}

	class ComboEvent implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {

			String item = (String) BMCDbox.getSelectedItem();
			if (item == "��ü") {
				BMCDField.setText("");
				BMCDField.setEnabled(false);
			} else {
				BMCDField.setEnabled(true);
			}

		}

	}

	class TableEvent extends MouseAdapter {
		@Override
		public void mousePressed(MouseEvent e) {
			int row = BMCDtable.getSelectedRow();

			if (row == -1) {
				return;
			}

			BMDesignData Ddata = (BMDesignData) BMCDtable.getValueAt(row, 2);
			BMCDarea.setText(Ddata.bigo);
		}
	}

}
